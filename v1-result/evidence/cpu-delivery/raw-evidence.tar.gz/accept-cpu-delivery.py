import hashlib
import json
import pathlib
import subprocess
import tarfile
import time

root = pathlib.Path('/mnt/c/Users/21812/Desktop/ai4math_26Summercamp/Alpha-Proof-26-summer-school')
out = root / '.downloads/cpu-delivery-acceptance-20260827'
build_log_path = pathlib.Path('/tmp/reap-cpu-delivery-build-20260827.log')
build_text = build_log_path.read_text()
assert 'COMMIT localhost/reap-cpu:v1-delivery-20260827' in build_text
assert 'Successfully tagged localhost/reap-cpu:v1-delivery-20260827' in build_text
for kind, name in [
    ('container', 'reap-delivery-source-check-20260827'),
    ('container', 'reap-delivery-smoke-20260827'),
    ('container', 'reap-delivery-proof-20260827'),
    ('volume', 'reap-delivery-smoke-20260827-out'),
]:
    checked = subprocess.run(['podman', kind, 'exists', name], capture_output=True, timeout=30)
    if checked.returncode != 1:
        raise RuntimeError(f'Acceptance {kind} already exists or cannot be checked: {name}; inspect without overwriting')
out.mkdir(exist_ok=False)
tag = 'localhost/reap-cpu:v1-delivery-20260827'
def sha(data):
    return hashlib.sha256(data).hexdigest()
def run(args, name):
    started = time.time()
    try:
        result = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=900)
    except subprocess.TimeoutExpired as exc:
        (out/(name+'.log')).write_bytes(exc.stdout or b'')
        (out/(name+'.command.json')).write_text(json.dumps({'argv':args,'returncode':None,'elapsed_seconds':time.time()-started,'status':'timeout; inspect existing container, do not retry'},indent=2)+'\n')
        raise
    (out/(name+'.log')).write_bytes(result.stdout)
    (out/(name+'.command.json')).write_text(json.dumps({'argv':args,'returncode':result.returncode,'elapsed_seconds':time.time()-started},indent=2)+'\n')
    print(json.dumps({'step':name,'returncode':result.returncode}),flush=True)
    if result.returncode:
        raise RuntimeError(result.stdout.decode(errors='replace')[-5000:])
    return result.stdout

image=json.loads(run(['podman','image','inspect',tag],'image-inspect'))[0]
image_id=image['Id']
assert image_id in build_text
assert image['Config']['User']=='reap'
probe_code = """import hashlib,json,os,pathlib
p=pathlib.Path('/opt/reap-tools/cpu_runtime')
print(json.dumps({'uid':os.getuid(),'files':{f.relative_to(p).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in p.rglob('*') if f.is_file() and '__pycache__' not in f.parts},'training_olean':pathlib.Path('/opt/reap/.lake/build/lib/lean/Reap/Training.olean').is_file(),'gpu_runtime_present':pathlib.Path('/opt/reap-tools/gpu_runtime').exists()}))
"""
probe=json.loads(run(['podman','run','--name','reap-delivery-source-check-20260827','--network','none','--entrypoint','python3',image_id,'-c',probe_code],'image-source-check'))
source_manifest=json.loads((root/'v1-result/source/source-manifest.json').read_text())
expected={name[len('cpu_runtime/'):]:entry['sha256'] for name,entry in source_manifest['files'].items() if name.startswith('cpu_runtime/')}
assert probe['files']==expected
assert probe['uid']==10001 and probe['training_olean'] and not probe['gpu_runtime_present']
archive=root/'v1-result/evidence/raw-evidence.tar.gz'
manifest=json.loads((root/'v1-result/evidence/raw-evidence-manifest.json').read_text())
assert sha(archive.read_bytes())==manifest['archive']['sha256']
with tarfile.open(archive,'r:gz') as package:
    member='proof-recheck/RecurrenceSquare.recheck.lean'
    data=package.extractfile(member).read()
    assert sha(data)==manifest['files'][member]['sha256']
    (out/'RecurrenceSquare.recheck.lean').write_bytes(data)

smoke='reap-delivery-smoke-20260827'
volume='reap-delivery-smoke-20260827-out'
run(['podman','run','--name',smoke,'--network','none','-v',volume+':/workspace/out','--entrypoint','reap-cpu-smoke',image_id],'smoke')
inspect=json.loads(run(['podman','inspect',smoke],'smoke-inspect'))[0]
assert inspect['State']['ExitCode']==0
assert inspect['HostConfig']['NetworkMode']=='none'
run(['podman','cp',smoke+':/workspace/out/cpu-smoke',str(out/'smoke-output')],'copy-smoke-output')
summaries=[json.loads(line) for line in (out/'smoke-output/sessions/summary.jsonl').read_text().splitlines()]
assert len(summaries)==2 and all(s['solved'] for s in summaries)

proof='reap-delivery-proof-20260827'
proof_output=run(['podman','run','--name',proof,'--network','none','-v',str(out/'RecurrenceSquare.recheck.lean')+':/workspace/batch/RecurrenceSquare.recheck.lean:ro','--entrypoint','bash',image_id,'-lc','lean --version && lake env lean /workspace/batch/RecurrenceSquare.recheck.lean'],'proof-recheck')
proof_inspect=json.loads(run(['podman','inspect',proof],'proof-inspect'))[0]
assert proof_inspect['State']['ExitCode']==0 and proof_inspect['HostConfig']['NetworkMode']=='none'
assert 'sorryAx' not in proof_output.decode()
assert 'propext' in proof_output.decode() and 'Quot.sound' in proof_output.decode()
build_log=pathlib.Path('/tmp/reap-cpu-delivery-build-20260827.log').read_bytes()
(out/'build.log').write_bytes(build_log)
summary={
 'schema':'reap.cpu-delivery-acceptance.v1','status':'PASS',
 'image_tag':tag,'image_id':image_id,'image_digest':image.get('Digest'),
 'source_archive_sha256':sha((root/'v1-result/source/source-snapshot.tar.gz').read_bytes()),
 'cpu_dockerfile_sha256':sha((root/'v1-result/docker/cpu.Dockerfile').read_bytes()),
 'build_exit_code':None,'outer_wrapper_exit_code':1,'build_log_sha256':sha(build_log),
 'build_artifact_verified':True,
 'wrapper_observation':{'source':'parent original exec session 69412 result','outer_exit_code':1,'error':'exit: : numeric argument required','exit_file_content':'','cause':'parent launch wrapper variable escaping; original Podman exit status was not retained','success_evidence':['COMMIT and Successfully tagged in unchanged build.log','full image ID in build.log equals inspected immutable image']},
 'user':image['Config']['User'],'network_mode':'none','cpu_mock_sessions_solved':len(summaries),
 'actual_uid':probe['uid'],'cpu_runtime_files_match_frozen_source':len(expected),'compiled_training_overlay_present':True,
 'existing_E_proof_recompiled':True,'proof_file_sha256':sha(data),
 'gpu_used':False,'gpu_ttt_rerun':False,'gpu_container_passed':False,'image_published':False,
 'scope':'Delivery CPU build artifact and runtime acceptance passed using local build cache. Original Podman exit code is unknown due to outer wrapper error. CPU mock smoke and existing proof recheck only; no GPU experiment repeated.'}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary),flush=True)
