"""One independently loaded, fixed-release GPU service for the real campaign."""
import argparse,hashlib,json,os,sys,threading,time
from pathlib import Path

ROOT=Path('/mnt/workspace/reap/runs/20260828-replica-collector')
PRIOR=Path('/mnt/workspace/reap-ttt-20260828-mixed-learner')
SOURCE='0103155583b260c7863ea58bbf2d3377444c272db0ea4f3a75dd49c40b65c98e'
ALLOWED={'mm-36267162d92ac4de7d4e-00001','mm-36267162d92ac4de7d4e-00002'}
sys.path.insert(0,str(ROOT/'code'))
p=argparse.ArgumentParser();p.add_argument('--replica',type=int,choices=(0,1),required=True);a=p.parse_args()
r=ROOT/('replica-'+str(a.replica));port=8761+a.replica

def save(name,value):
 with (r/name).open('x') as f:json.dump(value,f,allow_nan=False);f.flush();os.fsync(f.fileno())

runtime=server=thread=None
status={'returncode':1,'pid':os.getpid(),'port':port}
try:
 import torch
 assert torch.cuda.is_available() and torch.version.hip
 torch.set_num_threads(1);torch.set_num_interop_threads(1)
 from gpu_runtime.server import build_parser,build_backend,RuntimeHandler,ThreadingHTTPServer
 from gpu_runtime.mixed_learner_store import MixedLearnerStore
 from gpu_runtime import GpuRuntime
 release,_=MixedLearnerStore(PRIOR/'result/learner-store').load_release(SOURCE)
 args=build_parser().parse_args(['--backend','mixed-replay','--model-path','/mnt/workspace/models/REAL-Prover-fe76f68d','--verified-dataset-root',str(PRIOR/'datasets'),'--mathlib-dataset-root',str(PRIOR/'mathlib-datasets'),'--verified-max-distance','8','--max-post-update-kl','100'])
 start=time.monotonic();backend=build_backend(args)
 assert backend.hidden_size==3584 and backend.experience_contract()==release['contract']
 runtime=GpuRuntime(backend=backend,snapshot_root=r/'snapshots',learner_release_root=PRIOR/'result/learner-store',max_resident_sessions=1)
 class Handler(RuntimeHandler):pass
 Handler.runtime=runtime;Handler.backend_name='mixed-replay'
 server=ThreadingHTTPServer(('127.0.0.1',port),Handler)
 thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
 free,total=torch.cuda.mem_get_info()
 save('ready.json',{'ready':True,'epoch':time.time(),'pid':os.getpid(),'port':port,'resident_cap':1,'device':str(backend.device),'hip':torch.version.hip,'model_release_sha256':SOURCE,'contract':backend.experience_contract(),'torch_threads':torch.get_num_threads(),'torch_interop':torch.get_num_interop_threads(),'load_seconds':time.monotonic()-start,'device_free_bytes':free,'device_total_bytes':total,'allocated_bytes':torch.cuda.memory_allocated(),'reserved_bytes':torch.cuda.memory_reserved()})
 while not (r/'finish.json').exists():time.sleep(.5)
 finish=json.loads((r/'finish.json').read_bytes())
 assert set(finish)=={'retired_sessions'} and set(finish['retired_sessions'])<=ALLOWED
 assert finish['retired_sessions'] and len(set(finish['retired_sessions']))==len(finish['retired_sessions'])
 for sid in finish['retired_sessions']:assert runtime.retirement_receipt(sid)['status']=='released'
 assert runtime.actor.submit(lambda:not runtime._resident_session_ids and not runtime.sessions._states)
 server.shutdown();thread.join();server.server_close();server=None
 metrics=runtime.actor.metrics();runtime.close();runtime=None
 status.update({'returncode':0,'epoch':time.time(),'actor_metrics':metrics,'retired_sessions':finish['retired_sessions']})
except BaseException as exc:
 status['error']={'type':type(exc).__name__,'message':str(exc)}
finally:
 try:
  if server is not None:server.shutdown();server.server_close()
  if thread is not None:thread.join(timeout=3)
  if runtime is not None:runtime.close()
 except BaseException as exc:
  status['returncode']=1;status['cleanup_error']={'type':type(exc).__name__,'message':str(exc)}
 save('worker-exit.json',status)
raise SystemExit(status['returncode'])

