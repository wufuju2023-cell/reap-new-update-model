from copy import deepcopy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import campaign
import container_job
from cpu_runtime import closed_problem as cp


class CampaignPreparationTests(unittest.TestCase):
    def test_routing_passes_exact_endpoint_before_search_and_wrong_pin_is_local_rejection(self):
        plan = campaign.check_bundle(); p=plan['expected_attempts'][0]; sid=p['attempt_id']
        intent={'proposal':p,'intent_sha256':'a'*64}
        with tempfile.TemporaryDirectory() as directory:
            data=Path(directory); (data/'routes').mkdir()
            route={'intent_sha256':'a'*64,'endpoint':plan['endpoints'][1]}
            path=data/'routes'/(sid+'.json'); path.write_text(json.dumps(route))
            with patch.object(container_job,'DATA',data), patch.object(container_job,'check_intent',return_value=intent), \
                 patch.object(container_job,'run_collector',return_value={'status':'exhausted'}) as run, \
                 patch.object(container_job,'normalize_terminal',return_value={'checked':True}):
                self.assertEqual(container_job.search(plan,sid),{'checked':True})
                self.assertEqual(run.call_args.kwargs['gpu_base_url'],'http://127.0.0.1:18768')
                self.assertEqual(run.call_args.kwargs['model_release_sha256'],plan['model_release_sha256'])
                run.reset_mock(); route['endpoint']={**route['endpoint'],'model_release_sha256':'f'*64}
                path.write_text(json.dumps(route))
                with self.assertRaises(AssertionError): container_job.search(plan,sid)
                run.assert_not_called()

    def test_math_inputs_unchanged_and_only_scheduler_family_names_separate_run(self):
        plan=campaign.check_bundle()
        old=json.loads((campaign.BUNDLE.parent/'matchmaker-campaign-r3-run-20260828'/'plan.json').read_bytes())
        self.assertNotEqual(plan['run_sha256'],old['run_sha256'])
        self.assertEqual(plan['config'],old['config'])
        for current,previous in zip(plan['curriculum']['problems'],old['curriculum']['problems']):
            self.assertEqual({k:v for k,v in current.items() if k!='family_id'},
                             {k:v for k,v in previous.items() if k!='family_id'})
        for label in ('true-positive','false-negative'):
            self.assertEqual((campaign.BUNDLE/'inputs'/label/'attempt.lean').read_bytes(),
                (campaign.BUNDLE.parent/'matchmaker-campaign-r3-run-20260828'/'inputs'/label/'attempt.lean').read_bytes())

    def test_check_never_calls_bridge_or_subprocess_and_exact_ids(self):
        with patch.object(campaign.GpuHttpClient, "_request", side_effect=AssertionError("bridge forbidden")), \
                patch.object(campaign.subprocess, "run", side_effect=AssertionError("subprocess forbidden")):
            plan = campaign.check_bundle()
        self.assertEqual(plan["config"]["seed"], 2)
        self.assertEqual([(item["attempt_id"], item["polarity"]) for item in plan["expected_attempts"]], [
            ("mm-36267162d92ac4de7d4e-00001", "disprove"), ("mm-36267162d92ac4de7d4e-00002", "prove")])
        self.assertEqual(plan["config"]["total_steps"], 16)

    def test_wrappers_are_exact_opt_in_unfold_preflight_inputs(self):
        plan = campaign.check_bundle()
        for case in plan["cases"]:
            problem = next(p for p in plan["curriculum"]["problems"] if p["problem_id"] == case["problem_id"])
            prepared = cp.prepare(environment_sha256=plan["curriculum"]["environment_sha256"],
                declarations=(campaign.BUNDLE / "inputs/declarations.lean").read_bytes(),
                closed_prop_name=problem["closed_prop_name"], polarity=case["desired_polarity"], budget_steps=8, unfold_closed_prop=True)
            directory = campaign.BUNDLE / "inputs" / case["problem_id"]
            self.assertEqual(prepared["execution_source"], (directory / "attempt.lean").read_bytes())
            self.assertEqual(prepared["preflight_source"], (directory / "preflight.lean").read_bytes())
            self.assertEqual(campaign.file_hash(directory / "receipt.json"), case["prior_descriptor"]["compilation_receipt_sha256"])
            self.assertIs(campaign.read(directory / "receipt.json")["proof_verified"], False)

    def test_only_search_gets_host_network_and_image_cannot_float(self):
        plan = campaign.check_bundle()
        for phase in ("preflight", "search", "verify"):
            command = campaign.command_for(plan, phase, "true-positive" if phase == "preflight" else plan["expected_attempts"][0]["attempt_id"])
            self.assertEqual(command[command.index("--network")+1], "host" if phase == "search" else "none")
            self.assertIn("--pull=never", command)
            self.assertIn(plan["image_id"], command)
            self.assertNotIn("--rm", command)
            self.assertNotIn("--privileged", command)
            self.assertIn("type=volume,source="+plan["volume"]+",destination=/campaign", command)

    def test_inspect_requires_actual_network_image_and_native_volume(self):
        plan = campaign.check_bundle()
        valid = {"Image": plan["image_id"], "HostConfig": {"NetworkMode": "none"},
            "Config": {"User": "0:0", "Env": [k+"="+v for k,v in campaign.git_environment().items()], "Labels": {"reap.campaign": plan["run_sha256"]}},
            "Mounts": [{"Destination": "/campaign", "Type": "volume", "Name": plan["volume"], "RW": True},
                       {"Destination": "/bundle", "Type": "bind", "Source": str(campaign.BUNDLE), "RW": False}]}
        campaign.validate_inspect(plan, valid, "verify")
        changes = [lambda obj: obj["HostConfig"].update(NetworkMode="host"),
                   lambda obj: obj.update(Image="0"*64), lambda obj: obj["Mounts"][0].update(Type="bind"),
                   lambda obj: obj["Mounts"][1].update(RW=True), lambda obj: obj["Config"].update(User="10001")]
        for change in changes:
            altered = deepcopy(valid); change(altered)
            with self.assertRaises(AssertionError):
                campaign.validate_inspect(plan, altered, "verify")

    def test_corrupt_bundle_refused_without_mutation(self):
        with patch.object(campaign, "file_hash", return_value="0"*64), \
                patch.object(campaign.GpuHttpClient, "_request", side_effect=AssertionError("bridge forbidden")):
            with self.assertRaises(AssertionError):
                campaign.check_bundle()

    def test_fixed_campaign_is_not_a_random_or_performance_benchmark(self):
        plan = campaign.check_bundle()
        self.assertIn("not a random benchmark", plan["seed_selection"])
        self.assertEqual(plan["model_release_sha256"], "0103155583b260c7863ea58bbf2d3377444c272db0ea4f3a75dd49c40b65c98e")
        self.assertEqual(plan["native_root"], "/home/hsy/reap-experiments/replica-collector-20260828")


if __name__ == "__main__":
    unittest.main(verbosity=2)
