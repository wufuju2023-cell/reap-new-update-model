import hashlib,json,os,socket,stat,subprocess,sys,time,zipfile
from pathlib import Path,PurePosixPath
r=Path('/mnt/workspace/reap/runs/20260828-replica-collector')
u=Path('/mnt/workspace/reap/uploads/20260828-replica-collector')
assert not r.exists() and not r.is_symlink() and u.resolve()==u
prior=Path('/mnt/workspace/reap/runs/20260828-inference-replicas')
assert json.loads((prior/'worker-exit.json').read_bytes())['returncode']==0
assert not any((Path('/proc')/str(pid)).exists() for pid in [2338,2339,2340,2397])
for port in [8761,8762]:
 with socket.socket() as s:s.settimeout(1);assert s.connect_ex(('127.0.0.1',port))!=0
raw=(u/'code.zip').read_bytes()
assert hashlib.sha256(raw).hexdigest()=='097dc3d39dd6b6abb6209a3d004f5b7d236020012f644e8ce7f0443c06375b94'
values={}
with zipfile.ZipFile(u/'code.zip') as z:
 assert len(z.infolist())==len(set(z.namelist()))==56
 for i in z.infolist():
  p=PurePosixPath(i.filename)
  assert not p.is_absolute() and '..' not in p.parts and '\\' not in i.filename and not stat.S_ISLNK(i.external_attr>>16) and not i.is_dir()
  assert i.file_size<2*1024*1024
  values[i.filename]=z.read(i)
r.mkdir(exist_ok=False)
for name,b in values.items():
 p=r/name;p.parent.mkdir(parents=True,exist_ok=True)
 assert p.parent.resolve().is_relative_to(r)
 with p.open('xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
for i in range(2):(r/('replica-'+str(i))).mkdir()
def save(name,value):
 with (r/name).open('x') as f:json.dump(value,f);f.flush();os.fsync(f.fileno())
save('source-manifest.json',{k:hashlib.sha256(v).hexdigest() for k,v in values.items()})
save('launch-intent.json',{'epoch':time.time(),'archive_sha256':hashlib.sha256(raw).hexdigest(),'automatic_retry_allowed':False})
coordinator='''import json,os,subprocess,time
from pathlib import Path
r=Path('/mnt/workspace/reap/runs/20260828-replica-collector')
children=[];ready=[];status={'returncode':1,'automatic_retry_allowed':False}
def save(name,value):
 with (r/name).open('x') as f:json.dump(value,f);f.flush();os.fsync(f.fileno())
try:
 for i in range(2):
  d=r/('replica-'+str(i));env=os.environ.copy();env.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',TOKENIZERS_PARALLELISM='false',PYTHONUNBUFFERED='1')
  command=['/mnt/workspace/reap-v1-20260827-gpu/code/venv/bin/python','-B',str(r/'code/server_worker.py'),'--replica',str(i)]
  with (d/'server.log').open('xb') as log:p=subprocess.Popen(command,cwd=r/'code',env=env,stdout=log,stderr=subprocess.STDOUT)
  children.append(p);save('replica-'+str(i)+'/launch.json',{'pid':p.pid,'epoch':time.time(),'command':command})
  limit=time.monotonic()+600
  while not (d/'ready.json').exists():
   assert p.poll() is None,'service exited during startup'
   assert time.monotonic()<limit,'readiness unknown; no restart'
   time.sleep(.2)
  item=json.loads((d/'ready.json').read_bytes());assert item['pid']==p.pid and item['ready'] is True
  ready.append(item)
 assert ready[0]['pid']!=ready[1]['pid'] and ready[0]['contract']==ready[1]['contract']
 assert all(p.poll() is None for p in children)
 save('all-ready.json',{'services':ready,'epoch':time.time(),'two_independent_processes':True})
 codes=[p.wait() for p in children]
 status.update({'returncode':0 if codes==[0,0] else 1,'service_exit_codes':codes,'epoch':time.time()})
except BaseException as e:
 status['error']={'type':type(e).__name__,'message':str(e)}
 for p in children:
  if p.poll() is None:p.terminate()
 for p in children:
  try:p.wait(timeout=10)
  except subprocess.TimeoutExpired:p.kill();p.wait()
finally:save('suite-exit.json',status)
raise SystemExit(status['returncode'])
'''
with (r/'coordinator.log').open('xb') as log:
 p=subprocess.Popen([sys.executable,'-B','-c',coordinator],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
save('launch.json',{'coordinator_pid':p.pid,'epoch':time.time()})
print(json.dumps({'coordinator_pid':p.pid,'root':str(r),'members':len(values),'automatic_retry_allowed':False}))
