"""Freeze current runtime and original r3 input evidence; no network or search."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import shutil
import sys
import tempfile

ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent
OLD=ROOT/'.downloads/matchmaker-campaign-r3-run-20260828'
sys.path.insert(0,str(ROOT))
from cpu_runtime import matchmaker as mm

def raw(path): return path.read_bytes()
def sha(path): return hashlib.sha256(raw(path)).hexdigest()
def put(path,data):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as stream: stream.write(data)
def change(text,old,new):
    assert text.count(old)==1,repr(old)
    return text.replace(old,new)

oldmanifest=json.loads(raw(OLD/'manifest.json'))
for name,pin in oldmanifest['files_sha256'].items(): assert sha(OLD/name)==pin,name
assert not (OUT/'manifest.json').exists()
for name in oldmanifest['files_sha256']:
    if name.startswith('inputs/') or name=='frozen/VerifiedReplay.lean':
        put(OUT/name,raw(OLD/name))
# Freeze current sources, not old copies under new names. Include the small
# Python dependency packages; no weights, datasets, credentials or pycache.
for package in ('cpu_runtime','gpu_runtime'):
    for source in sorted((ROOT/package).glob('*.py')):
        put(OUT/'frozen'/package/source.name,raw(source))
for name in ('http_bridge.py','remote_http_job.py'):
    put(OUT/'transport'/name,raw(ROOT/'tools/amd_jupyter'/name))
plan=json.loads(raw(OLD/'plan.json'))
plan.pop('gpu_base_url')
plan['schema_version']='reap.replica-collector.campaign-plan.v1'
plan['native_root']='/home/hsy/reap-experiments/replica-collector-20260828'
plan['volume']='reap-replica-collector-20260828'
plan['model_release_sha256']='0103155583b260c7863ea58bbf2d3377444c272db0ea4f3a75dd49c40b65c98e'
plan['endpoints']=[dict(replica_id=f'replica-{i}',base_url=f'http://127.0.0.1:{18767+i}',
    deployment_id=f'reap-replica-20260828-{i}',model_release_sha256=plan['model_release_sha256']) for i in range(2)]
plan['transport_routes']=[dict(local_port=18767+i,target_port=8761+i,replica_id=f'replica-{i}',
    remote_jobs_suffix=f'replica-{i}-jobs') for i in range(2)]
# Rename only operator family labels for a separate scheduler run. Problem IDs,
# actual mathematical identities, source bytes, seed and budgets are unchanged.
for problem in plan['curriculum']['problems']: problem['family_id']='replica-'+problem['family_id']
plan['input_evidence']={'source_bundle_manifest_sha256':sha(OLD/'manifest.json'),
    'source':'matchmaker-campaign-r3-run-20260828',
    'prior_preflights_reused_as_input_evidence':True,'new_preflight_executed_during_prepare':False,
    'runtime_preflights_required_before_any_session':True,
    'identity_change':'operator family labels only; mathematical problem/source/seed/budget unchanged'}
with tempfile.TemporaryDirectory() as directory:
    with mm.Matchmaker.create(Path(directory)/'scheduler',plan['curriculum'],plan['config']) as scheduler:
        plan['run_sha256']=scheduler.run_sha256; expected=[]
        for _ in range(2):
            p=scheduler.plan_next(plan['model_release_sha256'])
            case=next(c for c in plan['cases'] if c['problem_id']==p['problem_id'])
            assert p['polarity']==case['desired_polarity']
            expected.append({k:p[k] for k in plan['expected_attempts'][0]})
            scheduler.reserve(p,case['prior_descriptor'])
        plan['expected_attempts']=expected
assert plan['run_sha256']!=json.loads(raw(OLD/'plan.json'))['run_sha256']
put(OUT/'plan.json',mm.canonical_bytes(plan))

text=(OLD/'campaign.py').read_text()
text=text.replace('from cpu_runtime.collector_batch import run_collector_batch',
 'from cpu_runtime.replica_collector import ReplicaCollector, run_replica_collector_batch, validate_endpoints')
text=change(text,'    assert plan["gpu_base_url"] == "http://127.0.0.1:18766"',
 '    validate_endpoints(plan["endpoints"])\n    assert [e["base_url"] for e in plan["endpoints"]] == ["http://127.0.0.1:18767", "http://127.0.0.1:18768"]')
text=change(text,'    name = "mm-campaign-r3-" + phase + "-" + key','    name = "replica-campaign-" + phase + "-" + key')
text=change(text,'            def search(intent):','            def search(intent, endpoint):')
text=change(text,'                write(mountpoint / "intents" / (sid + ".json"), intent)',
 '                write(mountpoint / "intents" / (sid + ".json"), intent)\n                write(mountpoint / "routes" / (sid + ".json"), {"endpoint": endpoint, "intent_sha256": intent["intent_sha256"]})')
start=text.index('            def retire(intent, envelope):')
end=text.index('            def verify(intent, envelope):',start)
text=text[:start]+text[end:]
text=change(text,'            report = run_collector_batch(scheduler, native / "batch", prepare_source=prepare_source,\n                provide_release=lambda: plan["model_release_sha256"], search=search, retire=retire, verify=verify)',
 '            with ReplicaCollector(native / "router", plan["endpoints"], search) as router:\n                report = run_replica_collector_batch(scheduler, native / "batch", router=router, prepare_source=prepare_source, verify=verify)')
text=change(text,'            expected_verdicts = {"true-positive": "proved", "false-negative": "disproved"}',
 '            expected_verdicts = {"replica-true-positive": "proved", "replica-false-negative": "disproved"}')
text=text.replace('"reap.matchmaker.campaign-result.v1"','"reap.replica-collector.campaign-result.v1"')
put(OUT/'campaign.py',text.encode())

text=(OLD/'container_job.py').read_text()
needle='def search(plan, sid):\n    intent = check_intent(plan, sid); label = intent["proposal"]["problem_id"]'
replacement=needle+'\n    route = read(DATA / "routes" / (sid + ".json"))\n    assert set(route) == {"endpoint", "intent_sha256"}\n    assert route["intent_sha256"] == intent["intent_sha256"]\n    assert route["endpoint"] in plan["endpoints"]\n    assert route["endpoint"]["model_release_sha256"] == intent["proposal"]["model_release_sha256"]'
text=change(text,needle,replacement)
text=change(text,'output_root=DATA / "sessions", gpu_base_url=plan["gpu_base_url"],',
 'output_root=DATA / "sessions", gpu_base_url=route["endpoint"]["base_url"],')
put(OUT/'container_job.py',text.encode())
put(OUT/'preparation-provenance.json',mm.canonical_bytes({'source_manifest_sha256':sha(OLD/'manifest.json'),
 'input_sha256':{n:sha(OUT/n) for n in oldmanifest['files_sha256'] if n.startswith('inputs/')},
 'current_source_sha256':{p.relative_to(OUT/'frozen').as_posix():sha(p) for p in sorted((OUT/'frozen').rglob('*.py'))},
 'GPU_or_bridge_called':False,'new_Lean_preflight_ran':False}))
# Tests and README may be added after preparation; freeze() binds the executable
# payload only. Never include collected/ or mutable test logs in the manifest.
names=[p.relative_to(OUT).as_posix() for p in OUT.rglob('*') if p.is_file() and
       (p.parts[len(OUT.parts)] in ('frozen','inputs','transport') or p.name in ('campaign.py','container_job.py','plan.json','preparation-provenance.json','prepare.py'))]
put(OUT/'manifest.json',mm.canonical_bytes({'schema_version':'reap.replica-collector.campaign-bundle.v1',
 'files_sha256':{n:sha(OUT/n) for n in sorted(names)},
 'scope':'local preparation; original r3 preflight inputs retained, two runtime preflights required; no GPU/search started'}))
print(json.dumps({'run_sha256':plan['run_sha256'],'attempts':plan['expected_attempts'],
 'manifest_sha256':sha(OUT/'manifest.json'),'files':len(names)},indent=2))
