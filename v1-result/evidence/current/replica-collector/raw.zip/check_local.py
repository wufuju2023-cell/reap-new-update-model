"""Local-only preparation checks. Optional image check never launches searches."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time
import unittest

BUNDLE=Path(__file__).resolve().parent
ROOT=BUNDLE.parents[1]
sys.path[:0]=[str(BUNDLE),str(ROOT)]
import campaign
LABEL=sys.argv[1]
OUT=BUNDLE/'checks'/LABEL
OUT.mkdir(parents=True,exist_ok=False)
def save(name,value):
    (OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def frozen_hashes():
    manifest=json.loads((BUNDLE/'manifest.json').read_bytes())
    return {n:hashlib.sha256((BUNDLE/n).read_bytes()).hexdigest() for n in manifest['files_sha256']}
before=frozen_hashes(); save('source-before.json',before)
modules=['test_campaign','tools.amd_jupyter.test_http_bridge','tools.amd_jupyter.test_http_evidence']
start=time.perf_counter()
with (OUT/'tests.log').open('w',encoding='utf-8') as stream:
    result=unittest.TextTestRunner(stream=stream,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromNames(modules))
after=frozen_hashes(); save('source-after.json',after)
receipt={'tests_run':result.testsRun,'passed':result.testsRun-len(result.failures)-len(result.errors)-len(result.skipped),
 'errors':len(result.errors),'failures':len(result.failures),'skipped':len(result.skipped),
 'seconds':time.perf_counter()-start,'source_before_after_equal':before==after,
 'GPU_or_bridge_called':False,'mock_Lean_only':True,'ok':result.wasSuccessful() and before==after}
save('tests-receipt.json',receipt)
print(json.dumps(receipt))
if not receipt['ok']: raise SystemExit(1)
if '--image-cli' in sys.argv:
    assert sys.platform.startswith('linux')
    plan=campaign.check_bundle()
    # No campaign volume: cannot reserve/create a search-side output or GPU ID.
    script="""import subprocess,sys,json
commands=[[sys.executable,'-B','/bundle/campaign.py','--check'],[sys.executable,'-B','/bundle/container_job.py','--help'],[sys.executable,'-B','-m','cpu_runtime.verified_collector','--help'],[sys.executable,'-B','-m','cpu_runtime.collector_verify','--help'],['lake','env','lean','--version']]
results=[]
for cmd in commands:
 p=subprocess.run(cmd,capture_output=True,text=True)
 results.append(dict(command=cmd,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr))
print(json.dumps(results))
sys.exit(0 if all(r['returncode']==0 for r in results) else 1)
"""
    command=['podman','create','--pull=never','--name','replica-campaign-cli-check-20260828',
       '--network','none','--user','0:0','--workdir','/opt/reap-runtime','--entrypoint','python3',
       '--env','PYTHONPATH=/bundle/frozen','--env','PYTHONDONTWRITEBYTECODE=1','--env','PYTHONOPTIMIZE=',
       *campaign.git_flags(),'--volume',str(BUNDLE)+':/bundle:ro',plan['image_id'],'-B','-c',script]
    save('cli-create-intent.json',{'command':command,'retry_allowed':False})
    made=subprocess.run(command,capture_output=True,text=True)
    save('cli-create.json',{'exit':made.returncode,'stdout':made.stdout,'stderr':made.stderr})
    if made.returncode: raise SystemExit(made.returncode)
    cid=made.stdout.strip()
    before=json.loads(subprocess.run(['podman','inspect',cid],check=True,capture_output=True).stdout)[0]
    save('cli-inspect-before.json',before)
    assert before['Image'].removeprefix('sha256:')==plan['image_id']
    assert before['HostConfig']['NetworkMode']=='none' and before['Config']['User']=='0:0'
    assert len(before['Mounts'])==1 and before['Mounts'][0]['Destination']=='/bundle' and before['Mounts'][0]['RW'] is False
    run=subprocess.run(['podman','start','--attach',cid],capture_output=True,text=True,timeout=180)
    (OUT/'cli-stdout.log').write_text(run.stdout,encoding='utf-8'); (OUT/'cli-stderr.log').write_text(run.stderr,encoding='utf-8')
    after=json.loads(subprocess.run(['podman','inspect',cid],check=True,capture_output=True).stdout)[0]
    save('cli-inspect-after.json',after)
    success=run.returncode==0 and after['State']['ExitCode']==0 and not after['State']['Running']
    save('cli-receipt.json',{'podman_exit':run.returncode,'container_exit':after['State']['ExitCode'],
       'commands':json.loads(run.stdout) if success else None,'ok':success,'network':'none','GPU_or_bridge_called':False,
       'independent_proof_or_new_preflight':False,'container_retained':cid})
    if not success: raise SystemExit(1)
