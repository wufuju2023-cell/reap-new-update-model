"""Local raw-evidence audit; never executes a model or replays a request."""
import hashlib,json,math,sys
from pathlib import Path
root=Path(__file__).resolve().parent/'collected'
def read(name):return json.loads((root/name).read_bytes())
def pin(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()
index=read('export-manifest.json')
for name,r in index['files'].items():
 raw=(root/name).read_bytes();assert len(raw)==r['bytes'] and hashlib.sha256(raw).hexdigest()==r['sha256'],name
manifest=read('source-manifest.json')
assert len(index['actual_code'])==67
for r in index['actual_code']:assert manifest['files_sha256'][r['path']]==r['sha256'],r['path']
report=read('result/report.json');worker=read('worker-exit.json')
if report.get('ok') is not True:
 assert report['real_7B_GPU_gate_passed'] is False and worker['probe_returncode']!=0
 partial={'status':'failed_real_stage_evidence_verified','scope':'Raw files and frozen code verified; complete GPU joint stage did not pass.',
  'files':len(index['files']),'actual_code_hashes':len(index['actual_code']),
  'report_sha256':hashlib.sha256((root/'result/report.json').read_bytes()).hexdigest(),
  'worker':worker,'error':report.get('error'),
  'committed_checkpoints':[read(f'result/journal/step-{n:08d}/checkpoint.json') for n in (1,2) if (root/f'result/journal/step-{n:08d}/checkpoint.json').exists()],
  'boundaries':['No training or HTTP retry was performed. Failed stage is not a completed mathematical or performance experiment.',
   'Large tensors were not downloaded. Any final full base/source immutability gate not reached by the failed worker remains unverified.']}
 with (root/'local-audit.json').open('x',encoding='utf8') as f:json.dump(partial,f,indent=2,allow_nan=False)
 print(json.dumps(partial));sys.exit(0)
assert report['ok'] is True and report['real_7B_GPU_gate_passed'] is True
assert worker['returncode']==worker['probe_returncode']==0 and not any(k in worker for k in ('error','probe_still_running'))
assert not any(k in report for k in ('error','cleanup_error','finalization_error'))
assert len(report['gates'])==10 and all(v is True for v in report['gates'].values())
for name in ('new_Lean_search','mathematical_verification_performed','ReplicaCollector_search_or_batch_executed','curriculum_generation','performance_claimed','mutation_retry_allowed','unknown_publication_fault_injected'):assert report[name] is False,name
assert read('result/actor1-before-second.json')==read('result/actor1-after-second.json')
pids={read('probe-launch.json')['pid']}
for n in (1,2):
 ready=read(f'result/service-{n-1}/ready.json');done=read(f'result/service-{n-1}/worker-exit.json');pids.add(ready['pid'])
 assert done['ok'] is True and done['pid']==ready['pid']
 assert ready['device']=='cuda:0' and ready['hip'] and ready['base_fingerprint']['parameter_tensors']==339
 initial=read(f'result/actor{n}-initial.json');created=read(f'result/actor{n}-create-response.json')
 release=report[f'release{n}'];selection=read(f'result/selection{n}.json')
 intent=read(f'result/intent{n}.json');head=selection['head']
 assert pin(head)==selection['head_sha256'] and head['model_release_sha256']==release['model_release_sha256']==intent['proposal']['model_release_sha256']
 assert head['step']==n and head['checkpoint_sha256']==report['first' if n==1 else 'second']['checkpoint_sha256']
 assert selection['learner_run_sha256']==head['run_sha256']==release['run_sha256']
 assert head['previous_head_sha256']==(None if n==1 else read('result/selection1.json')['head_sha256'])
 assert initial['optimizer_empty'] is True and initial['optimizer_steps']==initial['examples_seen']==0
 assert created['lineage']['model_release_sha256']==release['model_release_sha256']
 assert initial['metadata']['lineage']['weights_sha256']==release['weights_sha256']
 assert created['initialization_contract']==ready['contract']==release['contract']
 assert read(f'result/actor{n}-retire-response.json')['status']=='released'
 for kind in ('policy','value'):
  response=read(f'result/actor{n}-{kind}-response.json');assert response['policy_version']==0 and len(response['choices'])==1
  if kind=='policy':assert all(math.isfinite(v['logprob']) and v['logprob']<=0 for v in response['choices'][0]['logprobs']['content'])
assert len(pids)==3
assert report['release1']['model_release_sha256']!=report['release2']['model_release_sha256']
continuation=read('result/final-continuation.json')
assert continuation['stage_passed'] is True and continuation['checkpoint_sha256']==report['second']['checkpoint_sha256'] and continuation['release_sha256']==report['release2']['model_release_sha256']
result={'status':'passed','scope':'Independent local read-only raw-file/metadata audit; no GPU rerun, tensor decoding, Lean or mathematical outcome.',
 'files':len(index['files']),'actual_code_hashes':len(index['actual_code']),'report_sha256':hashlib.sha256((root/'result/report.json').read_bytes()).hexdigest(),
 'probe_returncode':worker['probe_returncode'],'worker_receipt_returncode':worker['returncode'],'three_model_pids':sorted(pids),'gates':report['gates'],
 'release1':report['release1']['model_release_sha256'],'release2':report['release2']['model_release_sha256'],
 'boundaries':['Large CAS/snapshot tensors were not downloaded or independently decoded. Full tensor/base/source immutability gates rely on the pinned real worker and its actual exit0.',
 'Two actual updates in a fresh independent run; no retry, new Lean search, complete ReplicaCollector batch, success-rate comparison, throughput claim or GPU unknown-publication fault injection.']}
with (root/'local-audit.json').open('x',encoding='utf8') as f:json.dump(result,f,indent=2,allow_nan=False)
print(json.dumps(result))
