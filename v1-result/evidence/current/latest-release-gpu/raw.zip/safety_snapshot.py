"""Explicit operator-authorized single safety snapshot; never a retry/keepalive."""
import hashlib,json,os,subprocess,time,urllib.request
from pathlib import Path
root=Path('/mnt/workspace/reap/runs/20260828-latest-release')
result=root/'result';before=json.loads((result/'actor1-before-second.json').read_bytes())
sid=before['metadata']['session_id'];assert before['metadata']['policy_version']==0
ready=json.loads((result/'service-0/ready.json').read_bytes());assert (Path('/proc')/str(ready['pid'])).exists()
out=result/'operator-safety-r1';out.mkdir(exist_ok=False)
def save(name,value):
 with (out/name).open('x') as f:
  json.dump(value,f,sort_keys=True,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
name='operator-safety-r1-20260828';path=f'/sessions/{sid}/snapshot/v1';body={'name':name,'for_experience':False}
save('intent.json',{'epoch':time.time(),'method':'POST','url':ready['url']+path,'body':body,'expected_observed_policy_version':0,
 'purpose':'extra operator safety preservation, outside original probe gates','automatic_retry_allowed':False,'pipe_keepalive':False})
request=urllib.request.Request(ready['url']+path,data=json.dumps(body).encode(),headers={'Content-Type':'application/json'},method='POST')
try:
 with urllib.request.urlopen(request,timeout=180) as response:
  raw=response.read();code=response.status
 save('http-response.json',{'status':code,'body':json.loads(raw),'body_sha256':hashlib.sha256(raw).hexdigest()})
 assert code==201 and json.loads(raw)=={'session_id':sid,'snapshot':name}
 snapshot=result/'service-0/snapshots'/sid/name
 helper=r'''
import base64,hashlib,io,json,sys
from pathlib import Path
import torch
torch.set_num_threads(1);torch.set_num_interop_threads(1)
from latest_probe import tree_digest
from gpu_runtime.learner_release_store import content_sha256
p=Path(sys.argv[1]);before=json.loads(Path(sys.argv[2]).read_bytes())
manifest=json.loads((p/'manifest.json').read_bytes());pins={}
for name in ('session.json','backend.json'):
 raw=(p/name).read_bytes();pins[name]=hashlib.sha256(raw).hexdigest()
 assert pins[name]==manifest['files'][name]['sha256']
logical=json.loads((p/'session.json').read_bytes());raw=json.loads((p/'backend.json').read_bytes())
state=torch.load(io.BytesIO(base64.b64decode(raw['payload'],validate=True)),map_location='cpu',weights_only=True)
actual=content_sha256(tree_digest(torch,{'backend':state,'metadata':logical}))
assert actual==before['complete_sha256'] and logical==before['metadata'] and logical['policy_version']==0
print(json.dumps({'complete_sha256':actual,'matches_actor1_before_second':True,'metadata_exact':True,'policy_version':0,
 'snapshot_files_sha256':pins,'manifest_sha256':hashlib.sha256((p/'manifest.json').read_bytes()).hexdigest(),
 'cpu_only_decode':True,'original_probe_gate':False}))
'''
 env=os.environ.copy();env.update(CUDA_VISIBLE_DEVICES='',HIP_VISIBLE_DEVICES='',PYTHONPATH=str(root/'code'),PYTHONDONTWRITEBYTECODE='1')
 completed=subprocess.run(['/mnt/workspace/reap-v1-20260827-gpu/code/venv/bin/python','-B','-c',helper,str(snapshot),str(result/'actor1-before-second.json')],cwd=root/'code',env=env,capture_output=True,timeout=180)
 save('decode-process.json',{'returncode':completed.returncode,'stderr':completed.stderr.decode(errors='replace'),'stdout':completed.stdout.decode(errors='replace')})
 assert completed.returncode==0
 audit=json.loads(completed.stdout);save('audit.json',audit)
 print(json.dumps({'status':'saved_and_compared','session_id':sid,'snapshot':name,'audit':audit}))
except BaseException as exc:
 save('error.json',{'type':type(exc).__name__,'message':str(exc),'automatic_retry_allowed':False})
 raise
