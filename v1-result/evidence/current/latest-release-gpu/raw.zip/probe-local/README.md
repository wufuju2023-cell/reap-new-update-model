# 最新发布消费联合机制验收准备

入口 `latest_probe.py`，完整远端参数见 `command.json`。默认不分配模型、不创建输出；只有 `--run` 执行。输出目录必须全新。生产源码和既有冻结实验均未修改。

运行需把新部署的 `code` 目录放入 `PYTHONPATH`，并在入口旁保留 `campaign-plan.json`。复用持久权重、旧 mixed R2 和既有严格数据包；原 source CAS 先复制到新输出的 `learner-store`，所有新训练和发布只写副本。原 CAS 和数据前后逐文件核验。

## 实际门

- 主进程一个真实 backend/learner，两个 spawn 子进程各自一个真实 backend/HTTP runtime；三个 PID 和完整基座指纹必须匹配，模型合同完全相同。
- 两次真实 `train_next_and_publish`；第二次在 provider 的 prepare 回调期间发布，prepare 只运行一次，最终预约必须从 R1 改取 R2。
- 真实 HTTP 创建 actor，分别精确核对 R1/R2 的 adapter/value 参数；各一次 policy/value，题内版本保持 0。子进程 Pipe 仅读取状态/准备信息及关闭，不代替 HTTP 推理。
- R1 首次推理之后建立完整私有态基线；第二次更新和 R2 创建之后再比对。期间不再次生成 R1，不把合法 RNG 前进混作污染。
- 两 actor 真正退休、两个子进程 exit 0；全部进程基座指纹前后不变。最终报告还必须配合外层主进程真实 exit 0 才可接受。

## 明确边界

只验发布和消费机制。复用旧计划中的编译描述用于预约身份，不重新搜索，不写 `accepted`、`exhausted` 或新的数学验证结果；两条预约故意保留 pending。此运行不调用 `ReplicaCollector.search`/完整 batch，其 latest 接线已有单独真实 tiny 测试；此前双独立服务 fixed-release Lean 证据也独立保留。本次没有未知发布的 GPU 故障注入、没有课程生成或效果对照。

参数和完整私态采用实际 worker 对真实 CPU 解码张量的 dtype/shape/字节 SHA 审计；小型 hash/metadata 文件落盘，不把它说成在本机重新计算远端张量。

## 本地机制验收

- Windows 三项通过，9.033 秒：tiny 真 Adam、三实际进程、独立 HTTP 创建/推理/退休；独立 unknown HTTP 单发；结构化张量摘要区分 shape/dtype/scalar 类型。准入与基座使用明确 fixture，不是 GPU 或 Lean 验收。
- WSL：默认无 `--run` 的完整 CLI 检查 exit 0；一项 stdlib unknown HTTP 单发测试通过。WSL 不具备 Torch，未复跑 tiny 三进程训练。
- 首轮调试发现 fixture 随机基座未固定和初始化合同摘要缺尾换行，均在任何 GPU 执行前修正；最终日志/回执和 `source-before/after.json` 保存定稿版本。

主要产物：`step1/2.json`、`selection1/2.json`、`intent1/2.json`、`actor*-*-intent/response.json`、`actor1-before-second.json` / `actor1-after-second.json`、两 `service-*/ready.json` / `worker-exit.json`、`report.json`、`final-continuation.json`。任一未知结果都保留原意图和已有产物，不重发训练、创建或退休。
