"""Tiny CPU autograd + real spawn/HTTP; admission/base fixture, no GPU/Lean."""
import json, sys, tempfile, unittest
from pathlib import Path
from copy import deepcopy
from unittest.mock import patch
import latest_probe as p

def fixture_base(backend,chunk):
    return {n:p.content_sha256(p.tree_digest(backend.torch,t)) for n,t in backend.model.named_parameters() if not n.startswith('adapters.')}

def fixture_backend(config):
    from tests.test_mixed_backend import MixedBackendTests
    holder=unittest.TestCase();backend=MixedBackendTests.backend(holder)
    backend._test_holder=holder
    backend.max_post_update_kl=100
    backend.model.add_adapter('__bootstrap__',backend.lora_config)
    backend.model.adapters['__bootstrap__'].requires_grad_(False)
    backend._checkpoint_adapter_specs=lambda:{name:(tuple(t.shape),t.dtype) for name,t in backend._adapter_state_dict('__bootstrap__').items()}
    with backend.torch.no_grad():
        for name,t in backend.model.named_parameters():
            if name in config.get('fixture_base',{}):t.copy_(backend.torch.tensor(config['fixture_base'][name],dtype=t.dtype))
    p.base_fingerprint=fixture_base
    return backend

class ProbeTests(unittest.TestCase):
    def test_tiny_two_commits_real_three_processes_HTTP_and_pending_reservations(self):
        from tests.test_continual_mixed_learner import ContinualMixedTests
        from tests.test_matchmaker import curriculum,config,source
        ContinualMixedTests.setUp(self);ContinualMixedTests.enable_v3(self)
        self.backend.max_post_update_kl=100
        learner=ContinualMixedTests.learner(self)
        pins=[d['dataset_sha256'] for d in learner.catalog if d['source']=='replay']
        human=[d['dataset_sha256'] for d in learner.catalog if d['source']=='mathlib_sft']
        new='8'*64
        data={'replay':{q:deepcopy(self.backend._test_dataset) for q in pins+[new]},
              'mathlib_sft':{q:deepcopy(self.backend._test_sft) for q in human}}
        plan=p.old.plan_batches(data,pins,human,new,seed=17,max_distance=8)
        cur=curriculum((1,1));cfg=config(max_attempts=2,max_inflight=2)
        campaign={'curriculum':cur,'config':cfg,'cases':[]}
        probe_scheduler=p.mm.Matchmaker.create(self.root/'plan-scheduler',cur,cfg)
        for _ in range(2):
            proposal=probe_scheduler.plan_next('1'*64);desc=source(proposal)
            campaign['cases'].append({'problem_id':proposal['problem_id'],'desired_polarity':proposal['polarity'],'prior_descriptor':desc})
            probe_scheduler.reserve(proposal,desc)
        probe_scheduler.close()
        out=self.root/'probe';out.mkdir()
        with patch.object(p,'base_fingerprint',fixture_base):
            cfg={'store':str(self.root/'store'),'fixture_base':{n:t.detach().tolist() for n,t in self.backend.model.named_parameters() if not n.startswith('adapters.')}}
            result=p.run_joint(self.runtime,self.backend,learner,data,plan,campaign,cfg,out,{},factory=fixture_backend)
        self.assertTrue(result['ok']);self.assertEqual(len(result['gates']),10)
        self.assertNotEqual(result['release1']['model_release_sha256'],result['release2']['model_release_sha256'])
        self.assertEqual(learner.sampler_state['step'],2)
        self.assertEqual(json.loads((out/'actor1-before-second.json').read_bytes()),json.loads((out/'actor1-after-second.json').read_bytes()))
        self.assertTrue(all(json.loads((out/f'service-{i}/worker-exit.json').read_bytes())['ok'] for i in range(2)))

    def test_http_unknown_is_single_submit_with_durable_intent(self):
        class Client:
            count=0
            def _request(self,*args):self.count+=1;raise TimeoutError('unknown')
        c=Client()
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(TimeoutError):p.http(c,Path(tmp),'operation','POST','/sessions/x',{})
            self.assertEqual(c.count,1)
            self.assertTrue((Path(tmp)/'operation-intent.json').exists())
            self.assertFalse((Path(tmp)/'operation-response.json').exists())

    def test_recursive_digest_distinguishes_dtype_shape_and_bool(self):
        import torch
        pin=lambda x:p.content_sha256(p.tree_digest(torch,x))
        self.assertNotEqual(pin(torch.tensor([1.])),pin(torch.tensor([[1.]])))
        self.assertNotEqual(pin({'x':True}),pin({'x':1}))

if __name__=='__main__':unittest.main()
