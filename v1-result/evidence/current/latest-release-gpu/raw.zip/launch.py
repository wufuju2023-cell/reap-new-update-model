"""One-shot remote launcher. Fill the frozen manifest below; never retry an unknown launch."""
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import socket
import stat
import subprocess
import sys
import time
import zipfile

# The parent fills these from the final local deployment manifest after packing.
EXPECTED_MANIFEST_SHA256 = "b2f139b151066d1bf2a0c790f38676b015275bf94d391b9c064c007815e4d5d8"
MANIFEST_JSON = '{\r\n  "source_archive_sha256": "50bd3fb37005694e97b5244b7def5ea7b33881d6e61adc5223998fcef30f4e7c",\r\n  "archive_sha256": "8dbb8930490de698126397e0f9fab94e8319b56502e3c49af7f2050ee52a25ed",\r\n  "archive_bytes": 262247,\r\n  "files_sha256": {\r\n    "campaign-plan.json": "b704e6be60a12345b49bb259afea6904b3733ff2f9da093857f53f97a75c06cb",\r\n    "code/containers/gpu/download_model.py": "bea18b600d5a70b3b2b97b80c8d9131fda48228b67b4f114be89575e85a27531",\r\n    "code/containers/gpu/smoke_continual_mixed_learner.py": "0809ed76abcf7b8d6d35eaea9c6a8c374e96e638a5d6be83dc255cfc4bdf7945",\r\n    "code/containers/gpu/smoke_experience_gpu.py": "46af7e9e283dd18ba0347036624730b23c33cc47c50e7fb357299359547ec615",\r\n    "code/containers/gpu/smoke_gpu.py": "e024b6bc9b23fca1c66c3ed679e6136ada01fab503733cb396a57892aac3b759",\r\n    "code/containers/gpu/smoke_inference_replicas.py": "9d09546e12c75fe8e177533db91f678398a9672318a2d3f35dd9994e03014894",\r\n    "code/containers/gpu/smoke_kl_guard.py": "c48ef92a8993570baf88928860eda2c20f3b217692e80b6329b35135ac7384bd",\r\n    "code/containers/gpu/smoke_learner_loop.py": "b13bae6fd2cc7185e93cc83a651d0e37c3ff601673a3e78397cc92016067ebf1",\r\n    "code/containers/gpu/smoke_mixed_learner.py": "f8bcfe309c74d0a13015b190fc8fdf37a4a2aafcc541ea865ac2aaf320beffec",\r\n    "code/containers/gpu/smoke_policy_scoring.py": "1ab5b81991d1e5603754bb1d77fc7a92f0868f15645fc418b409736bc914529e",\r\n    "code/containers/gpu/smoke_search_gpu.py": "12d1918fcc2d0145ba2e7dd90bcb73878fd2a222d593e06ab3d729fc2c5ed905",\r\n    "code/containers/gpu/smoke_snapshot_reuse.py": "404e2048b0f6dcb397fb454d19d065c738e3645eee481c334ac2f183e8f0e482",\r\n    "code/containers/gpu/smoke_verified_replay.py": "9dfb9b41c1d8ce8f863f0be86de6a24c19aedc73a93a47c4be7ca5fb370971b9",\r\n    "code/cpu_runtime/__init__.py": "0bfe0a5ea77214fa2846ea24b27751750e0134287b92f86118956df326ea8f2b",\r\n    "code/cpu_runtime/batch_solver.py": "936b0bf4dbfc39e1b488125f90cfcccd6905e8ccf58f57b4f8bd962096c0eb8c",\r\n    "code/cpu_runtime/closed_problem.py": "fe04e75b0802e98331ac050636f542bfe78e29f92d9346278fb356590fc576d0",\r\n    "code/cpu_runtime/collector_batch.py": "9cac4c779054d7611f7da7ba25c7d264121cbf31fc2314da95c70052a89dc56f",\r\n    "code/cpu_runtime/collector_verify.py": "c89d913d29f049de9182a0320da1c65551edbb81581b8a0755c6931fbe97c1dc",\r\n    "code/cpu_runtime/curriculum_admission.py": "e55c4e84d0c5d160a13ea222d3d34364ce7a87c86a466cc3400af6f702e91140",\r\n    "code/cpu_runtime/experience_policy.py": "392c56b990810257e963dba0947c6aa7bb76e9327e7409febe29401363bb1a38",\r\n    "code/cpu_runtime/http_clients.py": "c65d81a6f922c62c90d40a08113f9699d634b647e3798b3578a69df2dffa4488",\r\n    "code/cpu_runtime/matchmaker.py": "8536a531a9b8be98f9f145f2ec8d43a6b019f9884f4299eab9b8eb8ae899369f",\r\n    "code/cpu_runtime/mathlib_trajectory.py": "cea58743b5b457af2c8e712d275abad520a777d2376b2700e2507efe54dca1fd",\r\n    "code/cpu_runtime/mock_services.py": "e88fc60144fb5d732e6ef1c3d562f2a1b91eb22169bcf9f9bf60655ca4b75bfc",\r\n    "code/cpu_runtime/normalize_rollout.py": "f9108919ebbf8a30a9c810148a46b22e58fd9506e40cece3d83080b88664bfa2",\r\n    "code/cpu_runtime/online_batch.py": "eed38f205fdae681972e7227257e3870d62498ff8fa0179eeee001bb26f19671",\r\n    "code/cpu_runtime/online_ttt.py": "cf475e6ada531f749172473040620eb1f8d8f259e0f9e82ff22094d8c9d5301f",\r\n    "code/cpu_runtime/publish_experience.py": "df6aadf73ed9b40852269b8d7610a6c46cd723d77be8b11034ad7ef9a6e9d75b",\r\n    "code/cpu_runtime/reap_act_runner.py": "a068161c556bbe8d8475fe6db3d67e81bd84e9e8b3c2b43619c7aa8d742105ff",\r\n    "code/cpu_runtime/reap_prompt.py": "4160fe53124542542d646391c7dd089206b180b3b0e5af33188c3bea59020a03",\r\n    "code/cpu_runtime/released_attempts.py": "3af3d5945357e005faa18a552476b4148e261924608a894b63b0c6eb496a3ff2",\r\n    "code/cpu_runtime/replica_collector.py": "5450717b1ae4e514652305409c5ef92351a4fd8811d62b260a0e568f313f5924",\r\n    "code/cpu_runtime/run_toy_ttt.py": "a79e87cf391e298118b94d155d3c9cecedd27c9d89c840d718341eaf9fcc5e78",\r\n    "code/cpu_runtime/run_ttt.py": "6e31fa924fe7ce093e9882bf5d1c851ef1fc253ceedc553bd65f2b88ade1c03a",\r\n    "code/cpu_runtime/segmented_ttt.py": "7c739fcb364ad35dbe344be74664f7a8602ac9161c07cfcfe1157f76d7ac360c",\r\n    "code/cpu_runtime/target_curriculum.py": "2cb4de8cf768deb0505a32e1316ef0198575ef19f288c225345c57a78acc1ee2",\r\n    "code/cpu_runtime/target_variants.py": "368c7f3b2626ae1365680d77978f6c3a08a335961b79d461fbf4b4a6e2f1d000",\r\n    "code/cpu_runtime/transport_budget.py": "e0fd254e87f7e1f3cd3d53c3135fff2ea889a6cf3929be6866bb456fee83d1ac",\r\n    "code/cpu_runtime/verified_collector.py": "3ee7543ec54b2416acfcfd7da7b79a5f5dad3ee6298723f6c08deff32fc827c5",\r\n    "code/cpu_runtime/verified_dataset_store.py": "9b9052292aaa0d50f2a51a8409eb1bbc4e1124fef99a38b5ce4f3045a27b9d58",\r\n    "code/cpu_runtime/verified_trajectory.py": "e8a2366df58e739cd5b9e0bb8068b4b4dd0bd6fc8c5f46e0299295be79dffac4",\r\n    "code/gpu_runtime/__init__.py": "e8beeae6e7f1737717bb10b3badf9521fdc52c36ce1d9524b8547edff2a8317d",\r\n    "code/gpu_runtime/actor.py": "a648761fb9a2bc6a231cb5d9bc2f6985e3d39ffc8c620fb2d580e602e4760524",\r\n    "code/gpu_runtime/backend.py": "007309e2cce2395810237e897adbc48fd9d5db3794ba8394af2b512fcb2fe372",\r\n    "code/gpu_runtime/continual_mixed_learner.py": "56c1810827754b3d743b735304b8d04272fc10502d0caee2c54bdd5b38a6e0b6",\r\n    "code/gpu_runtime/continual_mixed_store.py": "91676d42af1b6fe6da4f2e24f5903b26d433d9dfff16a20d83f303c6bfd42b6c",\r\n    "code/gpu_runtime/errors.py": "9cf83587246115807bfd7025322fcf3317d13f42d1303bec435a4994010b1cb7",\r\n    "code/gpu_runtime/experience_store.py": "998be320e7a65e68c059263460d75f9ebd90e2ab3f7f4bc19c8e1f38096aaa87",\r\n    "code/gpu_runtime/identifiers.py": "c9bc4e1f79541896b60a76848a5ee33f0f0fb485582fb8fc04b65d5445cf538a",\r\n    "code/gpu_runtime/learner.py": "21eca972d360d7034e83b5b7c31f875a15bc0d7c3f14db659d8132478a51a191",\r\n    "code/gpu_runtime/learner_release_store.py": "3c26df9759351c76b42277994aeaac440039827417e3a4da4bff1e185294383b",\r\n    "code/gpu_runtime/mixed_backend.py": "c5651123a70bc7cbbb3f1df7eb9621a47c569612ed2cdca1da446bb25846a620",\r\n    "code/gpu_runtime/mixed_learner.py": "48133d35063918df44ceba771418ee31181952e248960af15c8f67b159ff7f2b",\r\n    "code/gpu_runtime/mixed_learner_store.py": "d858b8c26fde5ce094c2896db66d54e2a2cea8367aa0d43990e54a7900e76c85",\r\n    "code/gpu_runtime/mixed_objective.py": "238c553cb9938c763fe5cf89db99df1b81fbc1edac4fcdc9e3ff319fb72df23a",\r\n    "code/gpu_runtime/real_backend.py": "6dace0009133b525226e3d242b41f4d10870b38d47213359120cb90b7f211f48",\r\n    "code/gpu_runtime/release_head.py": "60a2dceda32719a2fc01e5b584a42c37d45816623fbd2450947961a0cf0a6010",\r\n    "code/gpu_runtime/runtime.py": "e0c8da70c3b5a43e9c799048fd71d78e31adbde2890bcfa302aa9249d680d5ce",\r\n    "code/gpu_runtime/schemas.py": "63fcf6a583d70210d31829aa2cef06e2b27e4b295b55337f02381a99b59caeb2",\r\n    "code/gpu_runtime/search_backend.py": "a389f7464621ca217f0535a202d70b35662c20f7c51e47b7741d73db271b69dd",\r\n    "code/gpu_runtime/search_objective.py": "62939272269085464e5111d6f412500be3f28a67192f25c2a479d307625687d0",\r\n    "code/gpu_runtime/server.py": "03f7c5a2df7ef10541468d63372b0c933b4b8f5ca580ac4fe165c89472705ce1",\r\n    "code/gpu_runtime/session_store.py": "cfe6be2cc1996c60c94272d7776dad10bb604038a355b8e8e4df4c002cc76510",\r\n    "code/gpu_runtime/snapshot_store.py": "2fe8b7f74e61ce623b893f17c1e6d250fd16801fbee9b6c690e7307b2f23cfd0",\r\n    "code/gpu_runtime/toy_backend.py": "2d049f456a0a2b408491258a70dc5d2505c63e1690134814ecce5bff5c505e6f",\r\n    "code/gpu_runtime/verified_backend.py": "bd3be78dd5e88d7af04cb945d141dd43ca90244a8b35b9d426ea62493b2e80a6",\r\n    "code/gpu_runtime/verified_objective.py": "b62bb7e98c926988507e777397a8421aca9b7e390a5badeda8ebf70424215fb2",\r\n    "code/latest_probe.py": "c7b54691d0d6f4c56a57d2c2bcc12bc00d39f2ad141e05c4cc4023e7a149e989",\r\n    "command.json": "32f9ed458fc06e27baf9537144c7147555bbb99cb4012a80db827b43b2390deb"\r\n  }\r\n}'
RUN = Path('/mnt/workspace/reap/runs/20260828-latest-release')
UPLOAD = Path('/mnt/workspace/reap/uploads/20260828-latest-release')
PRIOR = Path('/mnt/workspace/reap/runs/20260828-replica-collector')
SOURCE_SHA = '50bd3fb37005694e97b5244b7def5ea7b33881d6e61adc5223998fcef30f4e7c'


def require(value, message):
    if not value:
        raise RuntimeError(message)


def no_links(path):
    for item in (path, *path.parents):
        require(not item.is_symlink(), 'linked path refused')
    return path


def save(path, value):
    no_links(path)
    raw = (json.dumps(value, sort_keys=True, ensure_ascii=False, allow_nan=False)+'\n').encode()
    with path.open('xb') as stream:
        stream.write(raw); stream.flush(); os.fsync(stream.fileno())
    descriptor = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


WORKER = r'''
import json, os, subprocess, time
from pathlib import Path
r=Path('/mnt/workspace/reap/runs/20260828-latest-release')
def save(name,value):
    with (r/name).open('x') as f:
        json.dump(value,f,sort_keys=True,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
status={'returncode':1,'probe_returncode':None,'automatic_retry_allowed':False}
p=None
try:
    command=json.loads((r/'actual-command.json').read_bytes())
    env=os.environ.copy();env.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',
        TOKENIZERS_PARALLELISM='false',PYTHONUNBUFFERED='1',PYTHONDONTWRITEBYTECODE='1',
        PYTHONOPTIMIZE='',PYTHONPATH=str(r/'code'),OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
    save('probe-launch-intent.json',{'command':command,'epoch':time.time(),'automatic_retry_allowed':False})
    with (r/'probe.log').open('xb') as log:
        p=subprocess.Popen(command,cwd=r/'code',env=env,stdout=log,stderr=subprocess.STDOUT)
    save('probe-launch.json',{'pid':p.pid,'epoch':time.time(),'command':command})
    code=p.wait(timeout=1800)
    status['probe_returncode']=code
    if code==0:
        report=json.loads((r/'result/report.json').read_bytes())
        if report.get('ok') is not True or report.get('real_7B_GPU_gate_passed') is not True:
            raise RuntimeError('probe exit0 without complete GPU report')
        if any(k in report for k in ('error','cleanup_error','finalization_error')):
            raise RuntimeError('late report error')
        for index in range(2):
            d=r/'result'/('service-'+str(index))
            ready=json.loads((d/'ready.json').read_bytes())
            done=json.loads((d/'worker-exit.json').read_bytes())
            if done.get('ok') is not True or done.get('pid')!=ready.get('pid'):
                raise RuntimeError('child exit receipt missing or mismatched')
        continuation=json.loads((r/'result/final-continuation.json').read_bytes())
        if continuation.get('stage_passed') is not True:
            raise RuntimeError('final continuation not passed')
        status['returncode']=0
except BaseException as error:
    status['error']={'type':type(error).__name__,'message':str(error)}
    # A timeout/unknown leaves the original learner and all artifacts intact.
    # No retry, terminate, kill, cleanup or second invocation is attempted here.
    status['probe_still_running']=p is not None and p.poll() is None
finally:
    status['epoch']=time.time();save('worker-exit.json',status)
raise SystemExit(status['returncode'])
'''


def main():
    require(sys.platform.startswith('linux'), 'remote Linux only')
    require(re.fullmatch('[0-9a-f]{64}', EXPECTED_MANIFEST_SHA256), 'final manifest not filled')
    manifest_raw = MANIFEST_JSON.encode()
    require(hashlib.sha256(manifest_raw).hexdigest() == EXPECTED_MANIFEST_SHA256, 'manifest bytes changed')
    manifest = json.loads(manifest_raw)
    require(manifest['source_archive_sha256'] == SOURCE_SHA, 'wrong production source baseline')
    no_links(RUN); no_links(UPLOAD); no_links(PRIOR)
    require(not RUN.exists(), 'run root exists: inspect outcome, never launch twice')
    require(json.loads((PRIOR/'suite-exit.json').read_bytes())['service_exit_codes'] == [0,0], 'prior services not complete')
    require(json.loads((PRIOR/'suite-exit.json').read_bytes())['returncode'] == 0, 'prior suite failed')
    for index in range(2):
        pid = json.loads((PRIOR/('replica-'+str(index))/'ready.json').read_bytes())['pid']
        require(type(pid) is int and pid > 0 and not (Path('/proc')/str(pid)).exists(), 'prior PID still exists')
    for port in (8760,8761,8762):
        with socket.socket() as connection:
            connection.settimeout(1)
            require(connection.connect_ex(('127.0.0.1',port)) != 0, 'prior service port remains busy')
    archive = no_links(UPLOAD/'code.zip').read_bytes()
    require(len(archive) == manifest['archive_bytes'] and hashlib.sha256(archive).hexdigest() == manifest['archive_sha256'], 'archive differs')
    values = {}
    with zipfile.ZipFile(UPLOAD/'code.zip') as source:
        require(len(source.namelist()) == len(set(source.namelist())) == len(manifest['files_sha256']), 'duplicate/missing zip members')
        for item in source.infolist():
            path = PurePosixPath(item.filename)
            require(not path.is_absolute() and '..' not in path.parts and '\\' not in item.filename
                    and path.as_posix() == item.filename and not any(ord(c)<32 for c in item.filename), 'unsafe member path')
            require(not item.is_dir() and not stat.S_ISLNK(item.external_attr>>16) and item.file_size < 2*1024*1024, 'unsafe member type/size')
            allowed = item.filename in ('campaign-plan.json','command.json','code/latest_probe.py') or (
                item.filename.startswith(('code/gpu_runtime/','code/cpu_runtime/','code/containers/gpu/')) and item.filename.endswith('.py'))
            require(allowed, 'unexpected deploy member')
            raw = source.read(item)
            require(hashlib.sha256(raw).hexdigest() == manifest['files_sha256'][item.filename], 'member hash differs')
            if item.filename.endswith('.py'):
                compile(raw,item.filename,'exec')
            values[item.filename] = raw
    require({'code/latest_probe.py','campaign-plan.json','command.json'} <= set(values), 'runner, command or campaign missing')
    command = json.loads(values['command.json'])
    require(type(command) is list and all(type(v) is str for v in command) and len(command)>3, 'invalid command')
    require(command[:2] == ['/mnt/workspace/reap-v1-20260827-gpu/code/venv/bin/python','-B'], 'unexpected Python runtime')
    require(command[2] in (str(RUN/'latest_probe.py'),str(RUN/'code/latest_probe.py')), 'unexpected runner')
    command[2] = str(RUN/'code/latest_probe.py')
    require(command.count('--run') == 1 and command[command.index('--output-dir')+1] == str(RUN/'result'), 'run/output differs')
    require(command[command.index('--campaign-plan')+1] == str(RUN/'campaign-plan.json'), 'campaign path differs')
    require(command[command.index('--campaign-plan-sha256')+1] == hashlib.sha256(values['campaign-plan.json']).hexdigest(), 'campaign pin differs')
    require(Path(command[0]).is_file(), 'existing runtime missing; no installation/download fallback')
    RUN.mkdir(exist_ok=False)
    save(RUN/'launch-intent.json',{'epoch':time.time(),'archive_sha256':manifest['archive_sha256'],
        'manifest_sha256':EXPECTED_MANIFEST_SHA256,'command':command,'automatic_retry_allowed':False})
    for name, raw in values.items():
        path = RUN/name;path.parent.mkdir(parents=True,exist_ok=True);no_links(path)
        with path.open('xb') as stream:
            stream.write(raw);stream.flush();os.fsync(stream.fileno())
    save(RUN/'source-manifest.json',manifest)
    save(RUN/'actual-command.json',command)
    with (RUN/'worker.py').open('x') as stream:
        stream.write(WORKER);stream.flush();os.fsync(stream.fileno())
    with (RUN/'worker.log').open('xb') as log:
        process = subprocess.Popen([sys.executable,'-B',str(RUN/'worker.py')],cwd=RUN,
            stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    save(RUN/'launch.json',{'worker_pid':process.pid,'epoch':time.time(),'automatic_retry_allowed':False})
    print(json.dumps({'worker_pid':process.pid,'run_root':str(RUN),'members':len(values),'automatic_retry_allowed':False}))


if __name__ == '__main__':
    main()
