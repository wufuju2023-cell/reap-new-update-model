# fresh / chain / bank：本地机制与使用

2026-08-28。新增默认关闭的旧题内 TTT 经验来源管理；不改变 `search_visit_backup`、训练频率、搜索树或 GPU 调度。本阶段没有运行 GPU、Lean 搜索或效果对照。

| 模式 | 新题初始化 | 拒绝/回退规则 |
| --- | --- | --- |
| fresh | 固定完整 backend/base/objective/shape/gamma 合同的基座；空 lineage | 服务端合同不符时分配前拒绝 |
| chain | 明确前序 experience ID；同 family、满足 tags、不同题/session | 不自动选最新或回退 |
| bank | 获准 catalog 中同 family 且包含所需 tags；priority 降序、ID 升序 | 无匹配报错，仅显式 allow_fresh_fallback 才 fresh |

family/tag/priority 是操作者路由声明，不是语义检索或数学变换证明。只接受 legacy real-search/search_visit_backup theorem experience，拒绝 mixed learner release、actor/learner 与 local-mechanism 生产来源。independent-lean acceptance 是已有验收声明，本工具不重新执行 Lean或认证不可信仓库所有者。

catalog 含完整合同、来源 metadata、验收声明、权重/快照/发布 manifest pins，不复制权重。batch 每行含自包含 catalog/selection。上限128来源、4MiB catalog、10000目标、16MiB materialized manifest。

## 使用

下列文件名是示例，不代表已导出实验 catalog。contract.json 必须是实际 backend.experience_contract 完整值。真实 backend base_sha256 绑定冻结 tensor、配置和 tokenizer；本阶段未重新计算真实7B hash。

approvals.json：

```json
[{"experience_id":"accepted-prior","family_id":"recurrence","tags":["nat"],"priority":10}]
```

```bash
python -m cpu_runtime.experience_policy export-catalog --store-root /path/to/experiences --approvals-json approvals.json --contract-json contract.json --output catalog.json
```

将输出 sha256 固定为下列 CATALOG_SHA。queries.json 是数组，theorem_file 相对 project-dir，实际 source SHA 由工具读取：

```json
[{"mode":"chain","session_id":"next-01","theorem_file":"Inputs/Next.lean","family_id":"recurrence","tags":["nat"],"predecessor_experience_id":"accepted-prior","allow_fresh_fallback":false}]
```

```bash
python -m cpu_runtime.experience_policy materialize-batch --catalog catalog.json --catalog-sha256 CATALOG_SHA --query-json queries.json --project-dir /path/to/lean-project --output batch.jsonl
python -m cpu_runtime.online_batch --manifest batch.jsonl --project-dir /path/to/lean-project --output-dir /path/to/new-run --gpu-base-url http://GPU-ENDPOINT --gamma 0.99 --concurrency 2 --max-updates 5
```

第二条是实际执行入口，需已有 CPU Lean/GPU 服务，本阶段没有执行。gamma 必须匹配合同。fresh/bank 的 predecessor 必须 null。无匹配默认报错。输出存在或发布未知不覆盖、不自动重发。

单题 select 的 query 用 target_theorem_sha256 替换 theorem_file，其余同上：

```bash
python -m cpu_runtime.experience_policy select --catalog catalog.json --catalog-sha256 CATALOG_SHA --query-json single-query.json --output selection.json
```

在原单题 online_ttt 命令增加 `--experience-policy-record selection.json`。收据导出原有三个 pinned experience 参数，若同时手填，必须完整且相同。

## 执行门与默认兼容

CPU 在 create 前重验目标字节、session、规则、三 pin 与 gamma；HTTP create 加 expected_initialization_contract_sha256，服务端实际固定合同不符则分配前拒绝。CPU 先保存原 create receipt，再完整核合同/SHA、localv0、空 optimizer/buffer/events、theorem role、fresh 空 lineage或继承 source 全字段；失败不启动 snapshot/Lean、不重发 create。batch 恢复重验 policy 文件、session/report、create 收据及既有证明/来源门。

旧无 policy 请求不新增合同读取或字段。新 CPU 接不支持合同门的旧服务会在 Lean 前拒绝，不静默降级。实际 backend 首次合同计算可读取基座 tensors，之后沿用其固定缓存。

## 验收证据

- [Windows](windows-receipt.json)：105/105 pass，35.485秒；14新策略 tests + batch/online/HTTP/旧经验。
- [WSL 首轮全量](wsl-receipt.json)：105run、100pass、4skip、1error；旧 test_exact_lora_namespace_export_and_optimizer_scope 直接 import 未安装Torch。未改旧测试/覆盖失败记录。
- [WSL stdlib 独立复验](wsl-stdlib-receipt.json)：精确结果见回执，排除旧 TensorExperienceTests 类，完整保留其他控制路径。
- 两平台保存7源码 before/after hashes、日志与 CLI help。fixtures 使用 Toy 参数、构造验收声明及 mock Lean；本地 HTTP/Runtime/ExperienceStore 是实际执行，不能称真实7B或独立Lean验收。

覆盖来源真初始化、目录不修改、损坏拒绝、确定规则/不同源身份、显式fallback、CLI不覆盖、fullsourcepin、HTTP零分配合同门、回执错时Lean前停止/不重发、batch透传与恢复篡改拒绝。
