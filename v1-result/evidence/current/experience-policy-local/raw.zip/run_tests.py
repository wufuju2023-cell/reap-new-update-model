"""Bounded local mechanism regression; no GPU or Lean invocation."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time
import unittest

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
OUT = Path(__file__).resolve().parent
LABEL = sys.argv[1]
FILES = [
    'cpu_runtime/experience_policy.py', 'cpu_runtime/online_ttt.py',
    'cpu_runtime/online_batch.py', 'tests/test_experience_policy.py',
    'gpu_runtime/server.py', 'cpu_runtime/http_clients.py', 'tests/test_gpu_http.py',
]
MODULES = ['tests.test_experience_policy', 'tests.test_online_batch',
           'tests.test_online_ttt', 'tests.test_gpu_http', 'tests.test_experience']
if LABEL == 'wsl-stdlib':
    # The prior full WSL receipt is retained: one historical test imports torch
    # without its optional-dependency guard. Do not alter or relabel that run.
    MODULES[-1] = 'tests.test_experience.ExperienceTests'
def hashes():
    return {name: hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in FILES}
before = hashes()
(OUT/(LABEL+'-source-before.json')).write_text(json.dumps(before, indent=2)+'\n')
started = time.perf_counter()
with (OUT/(LABEL+'.log')).open('w', encoding='utf-8') as stream:
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(
        unittest.defaultTestLoader.loadTestsFromNames(MODULES))
elapsed = time.perf_counter()-started
after = hashes()
(OUT/(LABEL+'-source-after.json')).write_text(json.dumps(after, indent=2)+'\n')
cli = subprocess.run([sys.executable, '-B', '-m', 'cpu_runtime.experience_policy', '--help'],
    cwd=ROOT, capture_output=True, text=True)
(OUT/(LABEL+'-cli.log')).write_text(cli.stdout+cli.stderr, encoding='utf-8')
receipt = {'schema_version':'reap.experience-policy.local-tests.v1', 'platform':LABEL,
    'modules':MODULES, 'tests_run':result.testsRun,
    'passed':result.testsRun-len(result.failures)-len(result.errors)-len(result.skipped),
    'skipped':len(result.skipped), 'failures':len(result.failures), 'errors':len(result.errors),
    'seconds':elapsed, 'source_sha256':after, 'sources_before_after_equal':before==after,
    'cli_help_exit_code':cli.returncode, 'GPU_used':False, 'Lean_rerun':False,
    'scope':'Routing/HTTP/toy mechanism only; attestation fixtures do not independently verify Lean',
    'ok':result.wasSuccessful() and before==after and cli.returncode==0}
(OUT/(LABEL+'-receipt.json')).write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps(receipt, indent=2))
raise SystemExit(0 if receipt['ok'] else 1)
