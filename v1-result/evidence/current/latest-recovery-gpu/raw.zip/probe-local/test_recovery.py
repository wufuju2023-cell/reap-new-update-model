"""Tiny actual snapshot restore and two spawned HTTP services; no GPU/Lean."""
import unittest,json,sys
from pathlib import Path
from copy import deepcopy
import recover_consume as recovery
import latest_probe as shared
from test_latest_probe import fixture_backend,fixture_base

class Tests(unittest.TestCase):
    def test_original_private_snapshot_restored_and_R2_consumed_without_new_learn(self):
        from tests.test_continual_mixed_learner import ContinualMixedTests
        ContinualMixedTests.setUp(self);ContinualMixedTests.enable_v3(self)
        self.backend.max_post_update_kl=100
        learner=ContinualMixedTests.learner(self)
        first=learner.train_next();r1=learner.publish()
        self.runtime.create_session('original-r1',theorem_id='1'*64,model_release_sha256=r1['model_release_sha256'])
        baseline=shared.state_summary(self.runtime,self.backend,'original-r1')
        path=self.runtime.snapshot('original-r1','saved-state')
        second=learner.train_next(append_dataset_pins=['8'*64]);r2=learner.publish()
        current=shared.state_summary(self.runtime,self.backend,learner.learner_id)
        data={'head':{'model_release_sha256':r2['model_release_sha256']},'baseline':baseline,'snapshot':path,
            'snapshot_name':'saved-state','original_pids':[],'release':r2,'R2_parameters':current['parameters'],
            'intent':{'attempt_source':{'execution_source_sha256':'2'*64}}}
        cfg={'store':str(self.root/'store'),'fixture_base':{n:t.detach().tolist() for n,t in self.backend.model.named_parameters() if not n.startswith('adapters.')}}
        output=self.root/'recovery';output.mkdir()
        result=recovery.run_recovery(data,output,cfg,factory=fixture_backend)
        self.assertTrue(result['ok']);self.assertEqual(len(result['gates']),8)
        self.assertEqual(learner.sampler_state['step'],2)
        self.assertEqual(shared.state_summary(self.runtime,self.backend,learner.learner_id),current)
        self.assertEqual(json.loads((output/'actor1-restored-before.json').read_bytes()),baseline)
        self.assertEqual(json.loads((output/'actor1-restored-after-R2.json').read_bytes()),baseline)

if __name__=='__main__':unittest.main()
