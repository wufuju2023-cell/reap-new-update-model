"""Single immutable-source recovery launch. No learn/publish or retry."""
import hashlib,io,json,os,socket,stat,subprocess,sys,time,zipfile
from pathlib import Path,PurePosixPath
ROOT=Path('/mnt/workspace/reap/runs/20260828-latest-recovery')
OLD=Path('/mnt/workspace/reap/runs/20260828-latest-release')
UPLOAD=Path('/mnt/workspace/reap/uploads/20260828-latest-recovery')
PATCH_SHA='e71b3ab9b517b41801551e9874b5369a570a33a09e7d761fc8d8b8800b2ccfbd'
BASE_MANIFEST_SHA='c1f54aecb6239f38a37a9aec14a35218f92a0589b5de24bd4814983af4062fe8'
PATCH_FILES={'code/recover_consume.py': '33641acded89106df38cbb1b5048d1b8f3b6bb6989602dd181d39738df442bbd', 'command.json': 'e99028409b3734006b563e9c74c67fc98004c3adbb22b3b0f91ec9cfd24c0b4e'}
def require(ok,message):
 if not ok:raise RuntimeError(message)
def no_links(path):
 for p in (path,*path.parents):require(not p.is_symlink(),'linked path')
 return path
def save(path,value):
 with path.open('x') as f:json.dump(value,f,sort_keys=True,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
WORKER=r'''
import json,os,subprocess,time
from pathlib import Path
r=Path('/mnt/workspace/reap/runs/20260828-latest-recovery')
def save(name,value):
 with (r/name).open('x') as f:json.dump(value,f,sort_keys=True,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
status={'returncode':1,'probe_returncode':None,'automatic_retry_allowed':False};p=None
try:
 command=json.loads((r/'actual-command.json').read_bytes())
 env=os.environ.copy();env.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',TOKENIZERS_PARALLELISM='false',PYTHONUNBUFFERED='1',PYTHONDONTWRITEBYTECODE='1',PYTHONOPTIMIZE='',PYTHONPATH=str(r/'code'),OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
 save('probe-launch-intent.json',{'command':command,'epoch':time.time(),'automatic_retry_allowed':False,'new_training_steps':0,'publish_calls':0})
 with (r/'probe.log').open('xb') as log:p=subprocess.Popen(command,cwd=r/'code',env=env,stdout=log,stderr=subprocess.STDOUT)
 save('probe-launch.json',{'pid':p.pid,'command':command,'epoch':time.time()})
 code=p.wait(timeout=1800);status['probe_returncode']=code
 if code==0:
  report=json.loads((r/'result/report.json').read_bytes())
  if report.get('ok') is not True or report.get('real_7B_GPU_gate_passed') is not True:raise RuntimeError('missing complete GPU report')
  if report.get('new_training_steps')!=0 or report.get('publish_calls')!=0 or report.get('original_run_still_failed') is not True:raise RuntimeError('recovery scope differs')
  if any(k in report for k in ('error','cleanup_error','finalization_error')):raise RuntimeError('late error')
  if len(report['gates'])!=8 or not all(v is True for v in report['gates'].values()):raise RuntimeError('incomplete recovery gates')
  for i in range(2):
   d=r/'result'/f'service-{i}';ready=json.loads((d/'ready.json').read_bytes());done=json.loads((d/'worker-exit.json').read_bytes())
   if done.get('ok') is not True or done.get('pid')!=ready.get('pid'):raise RuntimeError('child receipt mismatch')
  save('recovery-complete.json',{'stage_passed':True,'original_run_still_failed':True,'new_training_steps':0,'publish_calls':0,'head':report['head']})
  status['returncode']=0
except BaseException as exc:status.update(error={'type':type(exc).__name__,'message':str(exc)},probe_still_running=p is not None and p.poll() is None)
finally:status['epoch']=time.time();save('worker-exit.json',status)
raise SystemExit(status['returncode'])
'''
def main():
 require(sys.platform.startswith('linux'),'Linux only')
 for path in (ROOT,OLD,UPLOAD):no_links(path)
 require(not ROOT.exists(),'run exists: do not launch again')
 require(json.loads((OLD/'worker-exit.json').read_bytes())['probe_returncode']==1,'original failure receipt differs')
 for pid in (3366,3367,3390,3391):require(not (Path('/proc')/str(pid)).exists(),'original owner still present')
 for port in (37373,34105):
  with socket.socket() as s:s.settimeout(1);require(s.connect_ex(('127.0.0.1',port))!=0,'old service port remains')
 base_raw=(OLD/'source-manifest.json').read_bytes();require(hashlib.sha256(base_raw).hexdigest()==BASE_MANIFEST_SHA,'base manifest differs')
 base=json.loads(base_raw);values={}
 for name,digest in base['files_sha256'].items():
  if not name.startswith('code/') or not name.endswith('.py'):continue
  p=PurePosixPath(name);require(not p.is_absolute() and '..' not in p.parts and p.as_posix()==name and '\\' not in name,'unsafe source member')
  raw=no_links(OLD/name).read_bytes();require(hashlib.sha256(raw).hexdigest()==digest,'old source changed');compile(raw,name,'exec');values[name]=raw
 require(len(values)==67,'original code closure differs')
 patch=no_links(UPLOAD/'code.zip').read_bytes();require(hashlib.sha256(patch).hexdigest()==PATCH_SHA,'patch archive differs')
 with zipfile.ZipFile(io.BytesIO(patch)) as z:
  require(len(z.namelist())==2 and set(z.namelist())==set(PATCH_FILES)=={'code/recover_consume.py','command.json'},'patch member mismatch')
  for info in z.infolist():
   require(not info.is_dir() and not stat.S_ISLNK(info.external_attr>>16) and info.file_size<2*1024*1024,'unsafe patch member')
   raw=z.read(info);require(hashlib.sha256(raw).hexdigest()==PATCH_FILES[info.filename],'patch source mismatch');values[info.filename]=raw
 compile(values['code/recover_consume.py'],'recover_consume.py','exec')
 command=json.loads(values['command.json'])
 require(command[:3]==['/mnt/workspace/reap-v1-20260827-gpu/code/venv/bin/python','-B',str(ROOT/'code/recover_consume.py')],'unexpected command')
 require(command.count('--run')==1 and command[command.index('--original-run')+1]==str(OLD) and command[command.index('--output-dir')+1]==str(ROOT/'result'),'unexpected input/output')
 ROOT.mkdir(exist_ok=False)
 save(ROOT/'launch-intent.json',{'epoch':time.time(),'base_manifest_sha256':BASE_MANIFEST_SHA,'patch_sha256':PATCH_SHA,'command':command,'automatic_retry_allowed':False,'new_training_steps':0,'publish_calls':0})
 for name,raw in values.items():
  path=ROOT/name;path.parent.mkdir(parents=True,exist_ok=True);no_links(path)
  with path.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
 save(ROOT/'source-manifest.json',{'original_source_manifest_sha256':BASE_MANIFEST_SHA,'patch_sha256':PATCH_SHA,'files_sha256':{k:hashlib.sha256(v).hexdigest() for k,v in values.items()}})
 save(ROOT/'actual-command.json',command)
 with (ROOT/'worker.py').open('x') as f:f.write(WORKER);f.flush();os.fsync(f.fileno())
 with (ROOT/'worker.log').open('xb') as log:p=subprocess.Popen([sys.executable,'-B',str(ROOT/'worker.py')],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 save(ROOT/'launch.json',{'worker_pid':p.pid,'epoch':time.time(),'automatic_retry_allowed':False})
 print(json.dumps({'worker_pid':p.pid,'root':str(ROOT),'old_code_files':67,'new_training_steps':0,'publish_calls':0}))
if __name__=='__main__':main()
