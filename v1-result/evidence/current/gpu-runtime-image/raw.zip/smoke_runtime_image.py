"""Run inside the actual candidate image, without GPU/model/network access."""
import hashlib
import importlib
import json
import os
from pathlib import Path
import tempfile
import threading
from http.server import ThreadingHTTPServer
from urllib.request import Request, urlopen

assert os.getuid() == 10001
assert not Path('/opt/models/REAL-Prover').exists(), 'local image smoke must not contain model weights'
manifest = json.loads(Path('/opt/reap-runtime-context-manifest.json').read_bytes())
checked = {}
for name, info in manifest['files'].items():
    if name.startswith(('gpu_runtime/', 'cpu_runtime/')):
        actual = Path('/opt/reap-gpu') / name
        digest = hashlib.sha256(actual.read_bytes()).hexdigest()
        assert digest == info['sha256'], name
        checked[name] = digest
for name in ('gpu_runtime.server', 'gpu_runtime.learner', 'gpu_runtime.continual_mixed_learner',
             'gpu_runtime.release_head', 'gpu_runtime.mixed_backend', 'cpu_runtime.verified_trajectory',
             'cpu_runtime.mathlib_trajectory', 'transformers', 'peft', 'accelerate'):
    importlib.import_module(name)
import torch
torch_pin = json.loads(Path('/opt/reap-base-torch.json').read_bytes())
assert str(torch.__version__) == torch_pin['version']
assert torch.version.hip == torch_pin['hip'] and torch.version.hip
assert str(Path(torch.__file__).resolve()) == torch_pin['module']
from gpu_runtime.runtime import GpuRuntime
from gpu_runtime.toy_backend import ToyBackend
from gpu_runtime.server import RuntimeHandler

with tempfile.TemporaryDirectory() as directory:
    runtime = GpuRuntime(backend=ToyBackend(), snapshot_root=directory, max_resident_sessions=2)
    class Handler(RuntimeHandler):
        pass
    Handler.runtime = runtime
    Handler.backend_name = 'toy'
    server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    def call(method, path, body=None):
        raw = None if body is None else json.dumps(body).encode()
        request = Request(f'http://127.0.0.1:{server.server_port}'+path, data=raw,
                          headers={'Content-Type':'application/json'}, method=method)
        with urlopen(request, timeout=20) as response:
            return json.load(response)
    try:
        health = call('GET', '/health')
        first = call('POST', '/sessions/container-a', {})
        second = call('POST', '/sessions/container-b', {})
        assert first['session_id'] == 'container-a' and second['session_id'] == 'container-b'
        assert first['policy_version'] == second['policy_version'] == 0
        for sid in ('container-a', 'container-b'):
            snapshot = call('POST', f'/sessions/{sid}/snapshot/v1', {'name':'final'})
            assert snapshot == {'session_id':sid,'snapshot':'final'}
            released = call('POST', f'/sessions/{sid}/retire/v1',
                            {'name':'final','expected_policy_version':0,'reuse_snapshot':True})
            assert released['status'] == 'released'
            assert call('GET', f'/sessions/{sid}/retire/v1') == released
        third = call('POST', '/sessions/container-c', {})
        assert third['session_id'] == 'container-c'
        call('DELETE', '/sessions/container-c')
        assert not runtime.backend._states
    finally:
        server.shutdown(); server.server_close(); runtime.close(); thread.join(timeout=5)

print(json.dumps({'ok':True,'uid':os.getuid(),'image_model_files':0,
    'source_hashes':checked,'torch':torch_pin,'cuda_available':torch.cuda.is_available(),
    'toy_http_sessions':3,'toy_retire_reuse':2,'capacity_reclaimed':True,
    'gpu_numerics_tested':False,'real_model_tested':False}, sort_keys=True), flush=True)
