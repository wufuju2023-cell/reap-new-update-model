"""Read immutable remote snapshots on CPU; never load weights or mutate the server."""
import base64
import gc
import hashlib
import io
import json
import time
from pathlib import Path

import torch

ROOT = Path('/mnt/workspace/reap-v1-20260827-multiround/snapshots')
torch.set_num_threads(2)


def manifest(value):
    tensors, metadata = {}, {}
    def walk(item, path):
        if torch.is_tensor(item):
            assert item.device.type == 'cpu'
            assert bool(torch.isfinite(item).all()), path
            h = hashlib.sha256()
            h.update(json.dumps({'shape': list(item.shape), 'dtype': str(item.dtype)}, sort_keys=True).encode())
            raw = item.detach().contiguous().reshape(-1).view(torch.uint8)
            for start in range(0, raw.numel(), 1024 * 1024):
                h.update(raw[start:start + 1024 * 1024].numpy().tobytes())
            tensors[path] = h.hexdigest()
        elif isinstance(item, dict):
            for key in sorted(item, key=str):
                walk(item[key], path + '/' + str(key))
        elif isinstance(item, (list, tuple)):
            for index, part in enumerate(item):
                walk(part, path + '/' + str(index))
        else:
            metadata[path] = item
    walk(value, '')
    encoded = json.dumps({'tensors': tensors, 'metadata': metadata}, sort_keys=True, allow_nan=False).encode()
    return {'sha256': hashlib.sha256(encoded).hexdigest(), 'tensors': tensors}


def read_snapshot(sid, name):
    directory = ROOT / sid / name
    mraw = (directory / 'manifest.json').read_bytes()
    meta = json.loads(mraw)
    assert meta['session_id'] == sid and meta['snapshot'] == name
    assert set(meta['files']) == {'session.json', 'backend.json'}
    decoded = {}
    for filename, spec in meta['files'].items():
        raw = (directory / filename).read_bytes()
        assert len(raw) == spec['bytes'] and hashlib.sha256(raw).hexdigest() == spec['sha256']
        decoded[filename] = json.loads(raw)
    state, backend = decoded['session.json'], decoded['backend.json']
    assert state['session_id'] == sid and backend['session_id'] == sid
    assert backend['schema_version'] == 'reap.gpu.real-search-backend.v1'
    assert backend['search_config']['gamma'] == .99
    payload = torch.load(io.BytesIO(base64.b64decode(backend.pop('payload'), validate=True)),
                         map_location='cpu', weights_only=True)
    groups = {name: manifest(payload[name]) for name in ('adapter', 'value_head', 'optimizer')}
    rng = payload['rng']
    groups['rng_counters'] = manifest({'cpu': rng['cpu'], 'device': rng['device'], 'seed': rng['seed'],
        'optimizer_steps': payload['optimizer_steps'], 'examples_seen': payload['examples_seen']})
    assert state['policy_version'] == payload['optimizer_steps']
    steps = sorted({float(v['step']) for v in payload['optimizer']['state'].values() if 'step' in v})
    assert steps == ([float(payload['optimizer_steps'])] if payload['optimizer_steps'] else [])
    b = [v for k, v in payload['adapter'].items() if 'lora_B' in k]
    result = {'path': str(directory), 'manifest_sha256': hashlib.sha256(mraw).hexdigest(),
        'manifest': meta, 'state': state, 'backend_metadata': backend, 'groups': groups,
        'all_tensors_finite': True, 'optimizer_steps': payload['optimizer_steps'],
        'examples_seen': payload['examples_seen'], 'optimizer_state_steps': steps,
        'lora_B_nonzero_tensors': sum(bool(torch.count_nonzero(v)) for v in b),
        'lora_B_tensor_count': len(b), 'rng_seed': rng['seed']}
    del payload, decoded
    gc.collect()
    return result


rows = []
for sid in ('multi-20260827-01r1', 'multi-20260827-05r2'):
    before = read_snapshot(sid, 'before-online-ttt')
    after = read_snapshot(sid, 'after-online-ttt')
    assert before['optimizer_steps'] == 0 and before['lora_B_nonzero_tensors'] == 0
    assert after['optimizer_steps'] > 0 and after['lora_B_nonzero_tensors'] > 0
    receipts = sorted((v['response'] for v in after['state']['event_receipts'].values()),
                      key=lambda r: r['policy_version'])
    assert [r['policy_version'] for r in receipts] == list(range(1, after['optimizer_steps'] + 1))
    assert not before['state']['event_receipts']
    comparisons = {}
    for name in ('adapter', 'value_head', 'optimizer'):
        assert before['groups'][name]['sha256'] == receipts[0]['detail']['parameter_diffs'][name]['before_sha256']
        assert after['groups'][name]['sha256'] == receipts[-1]['detail']['parameter_diffs'][name]['after_sha256']
        for previous, current in zip(receipts, receipts[1:]):
            assert previous['detail']['parameter_diffs'][name]['after_sha256'] == current['detail']['parameter_diffs'][name]['before_sha256']
        old, new = before['groups'][name]['tensors'], after['groups'][name]['tensors']
        comparisons[name] = {'before_sha256': before['groups'][name]['sha256'],
            'after_sha256': after['groups'][name]['sha256'], 'changed': sum(old[k] != new[k] for k in old.keys() & new.keys()),
            'added': len(new.keys() - old.keys()), 'removed': len(old.keys() - new.keys()),
            'snapshot_matches_first_last_receipt': True, 'all_intermediate_receipt_hashes_contiguous': True}
    # Preserve compact complete session metadata/receipts, not tensor bytes or thousands of tensor hashes.
    for snapshot in (before, after):
        snapshot['groups'] = {k: {'sha256': v['sha256'], 'tensor_count': len(v['tensors'])}
                              for k, v in snapshot['groups'].items()}
    rows.append({'session_id': sid, 'before': before, 'after': after, 'comparisons': comparisons})
assert rows[0]['before']['rng_seed'] != rows[1]['before']['rng_seed']
print(json.dumps({'ok': True, 'schema_version': 'reap.multiround-snapshot-cpu-audit.v1',
    'collected_at_epoch': time.time(), 'sessions': rows, 'distinct_session_rng_seeds': True,
    'scope': 'Actual immutable pre/post snapshot bytes and all mutable tensor fingerprints; no restore performed; no base-model rehash.'},
    ensure_ascii=True, allow_nan=False), flush=True)
