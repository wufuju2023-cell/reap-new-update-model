"""Thread-safe logical Session state independent of the GPU backend."""

from __future__ import annotations

from contextlib import contextmanager
from copy import deepcopy
from dataclasses import dataclass, field
import threading
import time
from typing import Any, Iterator

from .errors import DuplicateSessionError, SessionNotFoundError
from .identifiers import validate_identifier


@dataclass
class SessionState:
    session_id: str
    policy_version: int = 0
    adapter_metadata: dict[str, Any] = field(default_factory=dict)
    value_metadata: dict[str, Any] = field(default_factory=dict)
    optimizer_metadata: dict[str, Any] = field(default_factory=dict)
    reference_metadata: dict[str, Any] = field(default_factory=dict)
    buffer_metadata: dict[str, Any] = field(
        default_factory=lambda: {"events": {}, "pending_event_ids": [], "consumed_event_ids": []}
    )
    event_receipts: dict[str, dict[str, Any]] = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)

    def snapshot(self) -> dict[str, Any]:
        return {
            "schema_version": "reap.gpu.session.v1",
            "session_id": self.session_id,
            "policy_version": self.policy_version,
            "adapter_metadata": deepcopy(self.adapter_metadata),
            "value_metadata": deepcopy(self.value_metadata),
            "optimizer_metadata": deepcopy(self.optimizer_metadata),
            "reference_metadata": deepcopy(self.reference_metadata),
            "buffer_metadata": deepcopy(self.buffer_metadata),
            "event_receipts": deepcopy(self.event_receipts),
            "created_at": self.created_at,
        }

    @classmethod
    def from_snapshot(cls, raw: dict[str, Any]) -> "SessionState":
        if raw.get("schema_version") != "reap.gpu.session.v1":
            raise ValueError("unsupported session snapshot schema")
        session_id = validate_identifier(raw.get("session_id"), kind="session_id")
        version = raw.get("policy_version")
        if not isinstance(version, int) or isinstance(version, bool) or version < 0:
            raise ValueError("invalid policy_version in snapshot")
        return cls(
            session_id=session_id,
            policy_version=version,
            adapter_metadata=deepcopy(raw.get("adapter_metadata") or {}),
            value_metadata=deepcopy(raw.get("value_metadata") or {}),
            optimizer_metadata=deepcopy(raw.get("optimizer_metadata") or {}),
            reference_metadata=deepcopy(raw.get("reference_metadata") or {}),
            buffer_metadata=deepcopy(raw.get("buffer_metadata") or {}),
            event_receipts=deepcopy(raw.get("event_receipts") or {}),
            created_at=float(raw.get("created_at", time.time())),
        )


class SessionStore:
    def __init__(self) -> None:
        self._guard = threading.RLock()
        self._states: dict[str, SessionState] = {}
        self._locks: dict[str, threading.RLock] = {}

    def create(self, session_id: str, metadata: dict[str, dict[str, Any]]) -> SessionState:
        session_id = validate_identifier(session_id, kind="session_id")
        with self._guard:
            if session_id in self._states:
                raise DuplicateSessionError(f"session already exists: {session_id}")
            state = SessionState(
                session_id=session_id,
                adapter_metadata=deepcopy(metadata.get("adapter") or {}),
                value_metadata=deepcopy(metadata.get("value") or {}),
                optimizer_metadata=deepcopy(metadata.get("optimizer") or {}),
                reference_metadata=deepcopy(metadata.get("reference") or {}),
            )
            self._states[session_id] = state
            self._locks[session_id] = threading.RLock()
            return deepcopy(state)

    def delete(self, session_id: str) -> None:
        session_id = validate_identifier(session_id, kind="session_id")
        with self._guard:
            if session_id not in self._states:
                raise SessionNotFoundError(f"session not found: {session_id}")
            del self._states[session_id]
            del self._locks[session_id]

    def get(self, session_id: str) -> SessionState:
        session_id = validate_identifier(session_id, kind="session_id")
        with self._guard:
            try:
                return deepcopy(self._states[session_id])
            except KeyError as exc:
                raise SessionNotFoundError(f"session not found: {session_id}") from exc

    @contextmanager
    def locked(self, session_id: str) -> Iterator[SessionState]:
        session_id = validate_identifier(session_id, kind="session_id")
        with self._guard:
            try:
                lock = self._locks[session_id]
            except KeyError as exc:
                raise SessionNotFoundError(f"session not found: {session_id}") from exc
        with lock:
            with self._guard:
                state = self._states[session_id]
            yield state

    def replace_locked(self, session_id: str, state: SessionState) -> None:
        """Replace state while the caller holds this session's lock."""
        if state.session_id != session_id:
            raise ValueError("snapshot session id mismatch")
        with self._guard:
            if session_id not in self._states:
                raise SessionNotFoundError(f"session not found: {session_id}")
            self._states[session_id] = state
