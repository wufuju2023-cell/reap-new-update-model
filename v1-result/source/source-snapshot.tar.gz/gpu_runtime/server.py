#!/usr/bin/env python3
"""HTTP control/data plane for the session-isolated GPU runtime."""

from __future__ import annotations

import argparse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import re
from typing import Any

from .errors import (
    DuplicateSessionError,
    EventConflictError,
    GpuRuntimeError,
    InvalidIdentifierError,
    SessionNotFoundError,
    VersionConflictError,
)
from .real_backend import RealProverBackend
from .search_backend import RealSearchBackend
from .runtime import GpuRuntime
from .toy_backend import ToyBackend


_SESSION_PATH = re.compile(r"^/sessions/([^/]+)(?:/(.*))?$")


def _status_for(error: BaseException) -> int:
    if isinstance(error, SessionNotFoundError):
        return 404
    if isinstance(error, (DuplicateSessionError, VersionConflictError, EventConflictError)):
        return 409
    if isinstance(error, (InvalidIdentifierError, ValueError)):
        return 400
    if isinstance(error, GpuRuntimeError):
        return 422
    return 500


class RuntimeHandler(BaseHTTPRequestHandler):
    runtime: GpuRuntime
    backend_name: str
    server_version = "ReapGpuRuntime/1"

    def log_message(self, format: str, *args: object) -> None:
        return

    def _send(self, status: int, value: Any) -> None:
        data = json.dumps(value, ensure_ascii=False, allow_nan=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _read(self) -> dict[str, Any]:
        length = int(self.headers.get("Content-Length", "0"))
        if length > 8 * 1024 * 1024:
            raise ValueError("request body exceeds 8 MiB")
        raw = self.rfile.read(length)
        value = json.loads(raw or b"{}")
        if not isinstance(value, dict):
            raise ValueError("request body must be a JSON object")
        return value

    def _route(self) -> tuple[str, str]:
        match = _SESSION_PATH.fullmatch(self.path.split("?", 1)[0])
        if not match:
            raise ValueError("unknown path")
        return match.group(1), match.group(2) or ""

    def do_GET(self) -> None:
        if self.path.split("?", 1)[0] == "/health":
            self._send(200, {
                "ok": True,
                "backend": self.backend_name,
                "gpu_actor_completed": self.runtime.actor.completed,
                "gpu_actor_max_active": self.runtime.actor.max_active,
            })
            return
        self._send(404, {"error": "not_found"})

    def do_POST(self) -> None:
        try:
            session_id, action = self._route()
            body = self._read()
            if action == "":
                self._send(201, self.runtime.create_session(session_id))
            elif action == "policy/v1/chat/completions":
                self._send(200, self.runtime.policy(session_id, body))
            elif action == "value/v1/chat/completions":
                self._send(200, self.runtime.value(session_id, body))
            elif action == "learn/v1":
                event = body.get("event")
                self._send(200, self.runtime.learn(
                    session_id,
                    expected_policy_version=body.get("expected_policy_version"),
                    event=event,
                ))
            elif action == "snapshot/v1":
                path = self.runtime.snapshot(session_id, body.get("name"))
                self._send(201, {"session_id": session_id, "snapshot": path.name})
            elif action == "restore/v1":
                state = self.runtime.restore(session_id, body.get("name"))
                self._send(200, state)
            else:
                self._send(404, {"error": "not_found"})
        except BaseException as error:
            self._send(_status_for(error), {
                "error": type(error).__name__,
                "message": str(error),
            })

    def do_DELETE(self) -> None:
        try:
            session_id, action = self._route()
            if action:
                self._send(404, {"error": "not_found"})
                return
            self.runtime.delete_session(session_id)
            self._send(200, {"deleted": True, "session_id": session_id})
        except BaseException as error:
            self._send(_status_for(error), {
                "error": type(error).__name__,
                "message": str(error),
            })


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=8760)
    parser.add_argument("--backend", choices=("toy", "real", "real-search"), default="real")
    parser.add_argument("--gamma", type=float, help="required for real-search; must match actual Lean visit_discount")
    parser.add_argument("--model-path", default="/opt/models/REAL-Prover")
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--snapshot-root", type=Path, default=Path("/workspace/out/snapshots"))
    return parser


def main() -> int:
    args = build_parser().parse_args()
    if args.backend == "real-search":
        if args.gamma is None:
            raise SystemExit("--gamma is required for real-search")
        backend = RealSearchBackend(args.model_path, device=args.device, gamma=args.gamma)
    elif args.backend == "toy":
        backend = ToyBackend()
    else:
        backend = RealProverBackend(args.model_path, device=args.device)
    runtime = GpuRuntime(backend=backend, snapshot_root=args.snapshot_root)
    RuntimeHandler.runtime = runtime
    RuntimeHandler.backend_name = args.backend
    server = ThreadingHTTPServer((args.host, args.port), RuntimeHandler)
    try:
        print(json.dumps({"ready": True, "host": args.host, "port": args.port, "backend": args.backend}), flush=True)
        server.serve_forever()
    except KeyboardInterrupt:
        return 0
    finally:
        server.server_close()
        runtime.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
