"""Opt-in strict search objective; the legacy backend and server stay unchanged.

One event produces one transactional optimizer step through GpuRuntime. Runtime
owns rollback/quarantine. This subclass reuses named adapters, frozen base,
session RNG and tensor snapshots, but rejects cross-objective snapshot imports.
"""
from __future__ import annotations

import hashlib
import json
from typing import Any

from .backend import BackendLearnResult
from .real_backend import RealProverBackend
from .search_objective import (
    DEFAULT_VALUE_FLOOR, MAX_CANDIDATES, OBJECTIVE_KIND, VALUE_SEMANTICS,
    finite_number, nonnegative_integer, prepare_search_event, validate_gamma,
    validate_value_floor, value_to_distance,
)

SNAPSHOT_SCHEMA = "reap.gpu.real-search-backend.v1"
TOKENIZATION = "canonical_tactic_separate_tokenization_no_implicit_EOS_joint_token_sum"


class RealSearchBackend(RealProverBackend):
    def __init__(self, model_path: str, *, gamma: float,
                 value_floor: float = DEFAULT_VALUE_FLOOR,
                 max_sequence_tokens: int = 4096, max_candidates: int = MAX_CANDIDATES,
                 **kwargs: Any) -> None:
        self.gamma = validate_gamma(gamma)  # no implicit search-discount default
        self.value_floor = validate_value_floor(value_floor)
        self.max_sequence_tokens = nonnegative_integer(max_sequence_tokens, "max_sequence_tokens")
        self.max_candidates = nonnegative_integer(max_candidates, "max_candidates")
        if self.max_sequence_tokens < 2 or not 1 <= self.max_candidates <= MAX_CANDIDATES:
            raise ValueError("invalid search training safety limits")
        super().__init__(model_path, **kwargs)
        for name in ("learning_rate", "value_learning_rate", "max_grad_norm"):
            if finite_number(getattr(self, name), name) <= 0:
                raise ValueError(f"{name} must be positive")
        for name in ("kl_beta", "value_coefficient"):
            if finite_number(getattr(self, name), name) < 0:
                raise ValueError(f"{name} must be nonnegative")

    def _search_config(self) -> dict[str, Any]:
        return {"objective": OBJECTIVE_KIND, "value_semantics": VALUE_SEMANTICS,
                "gamma": self.gamma, "value_floor": self.value_floor,
                "max_distance": value_to_distance(0, self.gamma, value_floor=self.value_floor),
                "max_sequence_tokens": self.max_sequence_tokens, "max_candidates": self.max_candidates,
                "tokenization": TOKENIZATION, "policy_reduction": "visit_weighted_joint_token_sum",
                "kl_reduction": "visit_weighted_sum_of_prefix_next_token_KL_current_to_frozen_base",
                "kl_beta": self.kl_beta, "value_coefficient": self.value_coefficient,
                "learning_rate": self.learning_rate, "value_learning_rate": self.value_learning_rate,
                "max_grad_norm": self.max_grad_norm, "head": "sigmoid",
                "hidden_size": self.hidden_size, "lora_rank": self.lora_config.r}

    def _value_metadata(self, **extra: Any) -> dict[str, Any]:
        return {"hidden_size": self.hidden_size, **self._search_config(), **extra}

    def create_session(self, session_id: str) -> dict[str, dict[str, Any]]:
        metadata = super().create_session(session_id)
        # Tanh has no parameters; replacing it preserves optimizer references,
        # initialization and private RNG exactly, while changing only this mode.
        self.sessions[session_id].value_head[-1] = self.torch.nn.Sigmoid()
        metadata["value"] = self._value_metadata()
        metadata["adapter"]["objective"] = OBJECTIVE_KIND
        return metadata

    def value(self, session_id: str, request: Any) -> float:
        probability = super().value(session_id, request)
        return value_to_distance(probability, self.gamma, value_floor=self.value_floor)

    def export_session(self, session_id: str) -> dict[str, Any]:
        state = super().export_session(session_id)
        return {**state, "schema_version": SNAPSHOT_SCHEMA, "session_id": session_id,
                "search_config": self._search_config()}

    def import_session(self, session_id: str, state: dict[str, Any]) -> None:
        if (state.get("schema_version") != SNAPSHOT_SCHEMA or state.get("session_id") != session_id
                or state.get("search_config") != self._search_config()):
            raise ValueError("snapshot search objective/session/gamma/value semantics mismatch")
        legacy_wrapper = {**state, "schema_version": "reap.gpu.real-prover-backend.v1"}
        super().import_session(session_id, legacy_wrapper)

    def _assert_optimizer_scope(self, session_id: str, session: Any) -> list[Any]:
        adapter = self._adapter_parameters(session_id)
        parameters = adapter + list(session.value_head.parameters())
        allowed = {id(parameter) for parameter in parameters}
        optimized = [p for group in session.optimizer.param_groups for p in group["params"]]
        if len(optimized) != len({id(p) for p in optimized}) or {id(p) for p in optimized} != allowed:
            raise RuntimeError("optimizer scope differs from this session's adapter/value parameters")
        if any(p.requires_grad and id(p) not in allowed for p in self.model.parameters()):
            raise RuntimeError("base or another session's parameters unexpectedly require gradients")
        return parameters

    def _tensor_manifest(self, value: Any) -> dict[str, Any]:
        """Hash every session tensor in 1 MiB CPU chunks, never copy/hash the base."""
        torch = self.torch
        tensors: dict[str, str] = {}
        metadata: dict[str, Any] = {}

        def walk(item: Any, path: str) -> None:
            if torch.is_tensor(item):
                digest = hashlib.sha256()
                digest.update(json.dumps({"shape": list(item.shape), "dtype": str(item.dtype)}, sort_keys=True).encode())
                raw = item.detach().contiguous().reshape(-1).view(torch.uint8)
                for start in range(0, raw.numel(), 1024 * 1024):
                    digest.update(raw[start:start + 1024 * 1024].cpu().numpy().tobytes())
                tensors[path] = digest.hexdigest()
            elif isinstance(item, dict):
                for key in sorted(item, key=str):
                    walk(item[key], path + "/" + str(key))
            elif isinstance(item, (tuple, list)):
                for index, part in enumerate(item):
                    walk(part, path + "/" + str(index))
            else:
                metadata[path] = item

        walk(value, "")
        encoded = json.dumps({"tensors": tensors, "metadata": metadata}, sort_keys=True, allow_nan=False).encode()
        return {"sha256": hashlib.sha256(encoded).hexdigest(), "tensors": tensors}

    def session_fingerprints(self, session_id: str) -> dict[str, Any]:
        """Explicit audit helper; tensor hashes cover only mutable session state."""
        session = self._activate(session_id)
        return {
            "adapter": self._tensor_manifest(self.get_peft_model_state_dict(self.model, adapter_name=session_id)),
            "value_head": self._tensor_manifest(session.value_head.state_dict()),
            "optimizer": self._tensor_manifest(session.optimizer.state_dict()),
            "rng_counters": self._tensor_manifest({"cpu": session.cpu_rng_state,
                "device": session.device_rng_state, "seed": session.rng_seed,
                "optimizer_steps": session.optimizer_steps, "examples_seen": session.examples_seen}),
        }

    @staticmethod
    def _fingerprint_changes(before: dict[str, Any], after: dict[str, Any]) -> dict[str, Any]:
        result = {}
        for group in before:
            old, new = before[group]["tensors"], after[group]["tensors"]
            changed = sorted(key for key in old.keys() & new.keys() if old[key] != new[key])
            added, removed = sorted(new.keys() - old.keys()), sorted(old.keys() - new.keys())
            # Compact receipt; all tensors were compared. Full manifests can be
            # obtained via session_fingerprints without 100s of browser polls.
            diffs = {key: [old.get(key), new.get(key)] for key in sorted(set(changed + added + removed))}
            result[group] = {"before_sha256": before[group]["sha256"], "after_sha256": after[group]["sha256"],
                "before_tensors": len(old), "after_tensors": len(new), "changed_tensors": len(changed),
                "added_tensors": len(added), "removed_tensors": len(removed),
                "changed_names_sample": changed[:4], "diff_manifest_sha256": hashlib.sha256(
                    json.dumps(diffs, sort_keys=True, separators=(",", ":")).encode()).hexdigest()}
        return result

    def learn(self, session_id: str, event: dict[str, Any]) -> BackendLearnResult:
        session = self._activate(session_id)
        example = prepare_search_event(event, session_id=session_id, policy_version=session.optimizer_steps,
            gamma=self.gamma, value_floor=self.value_floor, max_candidates=self.max_candidates)
        torch = self.torch
        prompt = self.tokenizer(example["prompt"], return_tensors="pt").to(self.device)
        prompt_ids = prompt["input_ids"]
        if prompt_ids.shape[0] != 1 or prompt_ids.shape[1] < 1:
            raise ValueError("search training requires one nonempty prompt")
        tokenized = []
        for candidate in example["candidates"]:
            ids = self.tokenizer(candidate["tactic"], return_tensors="pt", add_special_tokens=False)["input_ids"].to(self.device)
            if ids.shape[0] != 1 or ids.shape[1] < 1 or prompt_ids.shape[1] + ids.shape[1] > self.max_sequence_tokens:
                raise ValueError("training sequence exceeds explicit limit or is empty; never truncate")
            tokenized.append(ids)
        parameters = self._assert_optimizer_scope(session_id, session)
        before = self.session_fingerprints(session_id)
        previous_use_cache = self.model.config.use_cache
        session.optimizer.zero_grad(set_to_none=True)
        policy_total = kl_total = 0.0
        candidate_trace = []
        try:
            with self._session_rng(session):
                self.model.config.use_cache = False
                self.model.eval()  # gradients remain enabled; frozen-model dropout must not perturb reference KL
                session.value_head.train()
                for candidate, target_ids in zip(example["candidates"], tokenized):
                    weight = candidate["target_probability"]
                    trace = {**candidate, "target_tokens": target_ids.shape[1]}
                    if weight == 0:
                        trace["trained"] = False
                        candidate_trace.append(trace)
                        continue
                    ids = torch.cat((prompt_ids, target_ids), dim=1)
                    attention = torch.cat((prompt.get("attention_mask", torch.ones_like(prompt_ids)), torch.ones_like(target_ids)), dim=1)
                    length = target_ids.shape[1]
                    output = self.model(input_ids=ids, attention_mask=attention, use_cache=False,
                        logits_to_keep=length + 1, return_dict=True)
                    logits = output.logits[:, -length - 1:-1, :].float()
                    if logits.shape[1] != length:
                        raise RuntimeError("model did not return the exact target scoring positions")
                    self._require_finite(logits, "search policy logits")
                    log_probs = self.functional.log_softmax(logits, dim=-1)
                    nll = -log_probs.gather(-1, target_ids.unsqueeze(-1)).sum()
                    with torch.no_grad(), self.model.disable_adapter():
                        reference = self.model(input_ids=ids, attention_mask=attention, use_cache=False,
                            logits_to_keep=length + 1, return_dict=True)
                        reference_logits = reference.logits[:, -length - 1:-1, :].float()
                        self._require_finite(reference_logits, "search reference logits")
                        reference_logs = self.functional.log_softmax(reference_logits, dim=-1)
                    kl = (log_probs.exp() * (log_probs - reference_logs)).sum()
                    term = weight * (nll + self.kl_beta * kl)
                    self._require_finite({"nll": nll, "kl": kl, "weighted_loss": term}, "search candidate loss")
                    term.backward()
                    policy_total += weight * float(nll.detach().cpu())
                    kl_total += weight * float(kl.detach().cpu())
                    trace.update(trained=True, joint_token_nll=float(nll.detach().cpu()), prefix_kl_sum=float(kl.detach().cpu()))
                    candidate_trace.append(trace)
                    del output, logits, log_probs, reference, reference_logits, reference_logs, nll, kl, term
                # A single prompt-only value regression, not one per candidate.
                output = self.model(**prompt, output_hidden_states=True, logits_to_keep=1,
                                    use_cache=False, return_dict=True)
                prediction = session.value_head(output.hidden_states[-1][:, -1, :].float()).squeeze()
                target = torch.tensor(example["value_target"], device=self.device, dtype=torch.float32)
                value_loss = self.functional.mse_loss(prediction, target)
                self._require_finite({"prediction": prediction, "target": target, "loss": value_loss}, "search value")
                (self.value_coefficient * value_loss).backward()
                value_loss_number = float(value_loss.detach().cpu())
                prediction_number = float(prediction.detach().cpu())
                total = policy_total + self.kl_beta * kl_total + self.value_coefficient * value_loss_number
                self._require_finite(total, "total search loss")
                self._require_finite([p.grad for p in parameters if p.grad is not None], "search gradients")
                grad_norm = torch.nn.utils.clip_grad_norm_(parameters, self.max_grad_norm, error_if_nonfinite=True)
                session.optimizer.step()
                self._require_finite(parameters, "search updated parameters")
                self._require_finite(session.optimizer.state_dict(), "search optimizer")
        finally:
            self.model.config.use_cache = previous_use_cache
            self.model.eval()
            session.value_head.eval()
            session.optimizer.zero_grad(set_to_none=True)
        session.optimizer_steps += 1
        session.examples_seen += 1
        after = self.session_fingerprints(session_id)
        detail = {"objective": OBJECTIVE_KIND, "loss": total, "policy_loss": policy_total,
            "kl": kl_total, "value_loss": value_loss_number, "value_before": prediction_number,
            "value_target": example["value_target"], "reward": example["reward"],
            "grad_norm": float(grad_norm.detach().cpu()), "optimizer_steps": session.optimizer_steps,
            "finite_loss": True, "finite_gradients": True, "finite_parameters": True,
            "finite_optimizer_state": True, "base_parameters_frozen": True,
            "base_content_hash_checked": False, "parameter_diffs": self._fingerprint_changes(before, after),
            "search_trace": {key: example[key] for key in ("tree_id", "step", "node_index", "policy_version", "gamma", "terminal_verified", "value_trace")},
            "candidate_targets": candidate_trace, "training_config": self._search_config(),
            "prompt_sha256": hashlib.sha256(example["prompt"].encode()).hexdigest()}
        return BackendLearnResult(
            adapter_metadata={"kind": "lora", "rank": self.lora_config.r,
                "objective": OBJECTIVE_KIND, "examples_seen": session.examples_seen},
            value_metadata=self._value_metadata(last_loss=value_loss_number),
            optimizer_metadata={"kind": "AdamW", "steps": session.optimizer_steps}, detail=detail)
