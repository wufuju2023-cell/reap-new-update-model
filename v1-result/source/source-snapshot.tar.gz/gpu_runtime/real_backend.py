"""Lazy PyTorch/Transformers backend for REAL-Prover test-time training.

Heavy GPU libraries are imported only when ``RealProverBackend`` is created,
so the control plane and its unit tests stay runnable on Windows/CPU hosts.
All public methods are expected to run through :class:`GpuActor`.
"""

from __future__ import annotations

import base64
from contextlib import contextmanager
from dataclasses import dataclass
import hashlib
import io
import math
from typing import Any

from .backend import BackendLearnResult
from .errors import DuplicateSessionError, SessionNotFoundError
from .schemas import ChatRequest


TARGET_MODULES = (
    "q_proj", "k_proj", "v_proj", "o_proj",
    "gate_proj", "up_proj", "down_proj",
)


@dataclass
class _RealSession:
    value_head: Any
    optimizer: Any
    optimizer_steps: int = 0
    examples_seen: int = 0
    rng_seed: int = 0
    cpu_rng_state: Any = None
    device_rng_state: Any = None


class RealProverBackend:
    """One frozen 7B base with isolated named LoRA/value/optimizer states."""

    def __init__(
        self,
        model_path: str,
        *,
        device: str = "cuda:0",
        expected_hidden_size: int = 3584,
        lora_rank: int = 16,
        lora_alpha: int = 32,
        learning_rate: float = 1e-4,
        value_learning_rate: float = 3e-4,
        kl_beta: float = 0.02,
        value_coefficient: float = 0.5,
        max_grad_norm: float = 1.0,
    ) -> None:
        try:
            import torch
            import torch.nn.functional as functional
            from peft import LoraConfig, get_peft_model
            from peft.utils import get_peft_model_state_dict, set_peft_model_state_dict
            from transformers import AutoModelForCausalLM, AutoTokenizer
        except ImportError as exc:  # pragma: no cover - exercised on the GPU image
            raise RuntimeError(
                "RealProverBackend requires torch, transformers, and peft from the GPU image"
            ) from exc

        self.torch = torch
        self.functional = functional
        self.get_peft_model_state_dict = get_peft_model_state_dict
        self.set_peft_model_state_dict = set_peft_model_state_dict
        self.device = torch.device(device)
        if self.device.type == "cuda" and not torch.cuda.is_available():
            raise RuntimeError("ROCm/CUDA device requested but torch.cuda.is_available() is false")
        self.tokenizer = AutoTokenizer.from_pretrained(model_path, local_files_only=True)
        if self.tokenizer.pad_token_id is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
        self.tokenizer.padding_side = "left"
        base = AutoModelForCausalLM.from_pretrained(
            model_path,
            local_files_only=True,
            torch_dtype=torch.bfloat16,
            low_cpu_mem_usage=True,
        ).to(self.device)
        hidden_size = int(base.config.hidden_size)
        if hidden_size != expected_hidden_size:
            raise RuntimeError(
                f"REAL-Prover hidden_size mismatch: expected {expected_hidden_size}, got {hidden_size}"
            )
        base.config.use_cache = True
        self.hidden_size = hidden_size
        self.lora_config = LoraConfig(
            r=lora_rank,
            lora_alpha=lora_alpha,
            lora_dropout=0.0,
            target_modules=list(TARGET_MODULES),
            bias="none",
            task_type="CAUSAL_LM",
            # PEFT's default initialization makes B zero and preserves the
            # frozen base policy. ``False`` would initialize random A and B.
            init_lora_weights=True,
        )
        self.model = get_peft_model(base, self.lora_config, adapter_name="__bootstrap__")
        self.model.eval()
        self.sessions: dict[str, _RealSession] = {}
        self.learning_rate = float(learning_rate)
        self.value_learning_rate = float(value_learning_rate)
        self.kl_beta = float(kl_beta)
        self.value_coefficient = float(value_coefficient)
        self.max_grad_norm = float(max_grad_norm)

    def _session(self, session_id: str) -> _RealSession:
        try:
            return self.sessions[session_id]
        except KeyError as exc:
            raise SessionNotFoundError(f"backend session not found: {session_id}") from exc

    def _activate(self, session_id: str) -> _RealSession:
        session = self._session(session_id)
        self.model.set_adapter(session_id)
        return session

    def _adapter_parameters(self, session_id: str) -> list[Any]:
        marker = f".{session_id}."
        parameters = [parameter for name, parameter in self.model.named_parameters() if marker in name]
        if not parameters:
            raise RuntimeError(f"no LoRA parameters found for adapter {session_id}")
        for parameter in parameters:
            parameter.requires_grad_(True)
        return parameters

    def _new_rng(self, session_id: str) -> tuple[int, Any, Any]:
        # A session's initialization/sampling must not depend on request order
        # or consume another session's (or the host's) random stream.
        seed = int.from_bytes(hashlib.sha256(session_id.encode("utf-8")).digest()[:8], "big") % (2**63)
        cpu_state = self.torch.Generator(device="cpu").manual_seed(seed).get_state()
        device_state = None
        if self.device.type == "cuda":
            device_state = self.torch.Generator(device=self.device).manual_seed(seed).get_state()
        return seed, cpu_state, device_state

    @contextmanager
    def _session_rng(self, session: _RealSession):
        """Commit the private stream on success; failed calls consume no RNG."""
        torch = self.torch
        devices = [self.device.index if self.device.index is not None else torch.cuda.current_device()] if self.device.type == "cuda" else []
        if session.cpu_rng_state is None or (devices and session.device_rng_state is None):
            raise RuntimeError("session RNG state is missing")
        # GpuActor serializes this process-wide swap. fork_rng restores the
        # outside CPU/selected-device streams even when generation raises.
        with torch.random.fork_rng(devices=devices):
            torch.set_rng_state(session.cpu_rng_state)
            if devices:
                torch.cuda.set_rng_state(session.device_rng_state, device=self.device)
            yield
            cpu_state = torch.get_rng_state().clone()
            device_state = torch.cuda.get_rng_state(self.device).clone() if devices else None
            session.cpu_rng_state = cpu_state
            session.device_rng_state = device_state

    def create_session(self, session_id: str) -> dict[str, dict[str, Any]]:
        if session_id in self.sessions:
            raise DuplicateSessionError(f"backend session already exists: {session_id}")
        torch = self.torch
        seed, cpu_state, device_state = self._new_rng(session_id)
        session = _RealSession(None, None, rng_seed=seed, cpu_rng_state=cpu_state, device_rng_state=device_state)
        added_adapter = False
        try:
            with self._session_rng(session):
                self.model.add_adapter(session_id, self.lora_config)
                added_adapter = True
                self.model.set_adapter(session_id)
                session.value_head = torch.nn.Sequential(
                    torch.nn.Linear(self.hidden_size, 256),
                    torch.nn.SiLU(),
                    torch.nn.Linear(256, 1),
                    torch.nn.Tanh(),
                ).to(device=self.device, dtype=torch.float32)
                adapter_parameters = self._adapter_parameters(session_id)
                session.optimizer = torch.optim.AdamW(
                    [
                        {"params": adapter_parameters, "lr": self.learning_rate},
                        {"params": list(session.value_head.parameters()), "lr": self.value_learning_rate},
                    ]
                )
        except BaseException:
            if added_adapter:
                self.model.delete_adapter(session_id)
            raise
        self.sessions[session_id] = session
        return {
            "adapter": {"kind": "lora", "rank": self.lora_config.r, "initial_equivalent_to_base": True},
            "value": {"hidden_size": self.hidden_size, "head": "3584-256-1-tanh"},
            "optimizer": {"kind": "AdamW", "steps": 0},
            "reference": {"kind": "frozen_base", "adapter_disabled": True},
            "rng": {"seed": seed, "scope": "session", "device_type": self.device.type},
        }

    def delete_session(self, session_id: str) -> None:
        self._session(session_id)
        del self.sessions[session_id]
        self.model.delete_adapter(session_id)

    def _encoded_prompt(self, request: ChatRequest) -> dict[str, Any]:
        return self.tokenizer(request.prompt, return_tensors="pt").to(self.device)

    def _score_generated_tokens(self, encoded: dict[str, Any], token_ids: list[int]) -> list[dict[str, Any]]:
        """Raw log P(token|prefix), one vocabulary vector and one row KV cache.

        Re-score rather than retain generate's processed scores (temperature,
        top-k, etc.) or an entire generated_length × vocabulary tensor. This
        costs extra forward passes but bounds score storage independently of
        completion length. Qwen2's logits_to_keep=1 also bounds prefill logits.
        """
        if not token_ids:
            return []
        torch = self.torch
        input_ids = encoded["input_ids"]
        attention_mask = encoded.get("attention_mask", torch.ones_like(input_ids)).clone()
        cache = None
        row: list[dict[str, Any]] = []
        for index, token_id in enumerate(token_ids):
            position_ids = attention_mask.long().cumsum(-1) - 1
            position_ids.masked_fill_(attention_mask == 0, 1)
            output = self.model(
                input_ids=input_ids, attention_mask=attention_mask,
                position_ids=position_ids[:, -input_ids.shape[1]:],
                past_key_values=cache, use_cache=True, logits_to_keep=1,
                return_dict=True,
            )
            logits = output.logits[:, -1, :].float()
            self._require_finite(logits, "raw policy logits")
            score = torch.log_softmax(logits, dim=-1)[0, token_id]
            self._require_finite(score, "raw policy token logprob")
            row.append({
                "token": self.tokenizer.decode([token_id], skip_special_tokens=False),
                "logprob": float(score.item()),
            })
            if index + 1 < len(token_ids):
                cache = output.past_key_values
                if cache is None:
                    raise RuntimeError("raw policy scoring requires a KV cache")
                input_ids = torch.tensor([[token_id]], device=self.device, dtype=encoded["input_ids"].dtype)
                attention_mask = torch.cat((attention_mask, torch.ones_like(input_ids)), dim=1)
            del output, logits, score
        return row

    def policy(self, session_id: str, request: ChatRequest) -> tuple[list[str], list[list[dict[str, Any]]]]:
        session = self._activate(session_id)
        torch = self.torch
        self.model.eval()
        encoded = self._encoded_prompt(request)
        do_sample = request.temperature > 0
        generation_options: dict[str, Any] = {
            "do_sample": do_sample,
            "num_return_sequences": request.n if do_sample else 1,
            "max_new_tokens": request.max_tokens,
            "pad_token_id": self.tokenizer.pad_token_id,
            "eos_token_id": self.tokenizer.eos_token_id,
            "return_dict_in_generate": False,
            "output_scores": False,
            "output_logits": False,
        }
        if do_sample:
            generation_options["temperature"] = max(request.temperature, 1e-5)
        contents: list[str] = []
        logprobs: list[list[dict[str, Any]]] = []
        with self._session_rng(session), torch.no_grad():
            sequences = self.model.generate(**encoded, **generation_options)
            prompt_length = encoded["input_ids"].shape[1]
            eos = self.tokenizer.eos_token_id
            eos_ids = set(eos if isinstance(eos, (list, tuple)) else [eos])
            for sequence in sequences:
                token_ids = sequence[prompt_length:].tolist()
                for index, token_id in enumerate(token_ids):
                    if token_id in eos_ids:
                        # Count the first EOS decision, never subsequent batch
                        # padding (including when pad_token_id == eos_token_id).
                        if any(item != self.tokenizer.pad_token_id for item in token_ids[index + 1:]):
                            raise ValueError("non-padding tokens after generated EOS")
                        token_ids = token_ids[:index + 1]
                        break
                contents.append(self.tokenizer.decode(token_ids, skip_special_tokens=True).strip())
                logprobs.append(self._score_generated_tokens(encoded, token_ids))
        if not do_sample and request.n > 1:
            contents *= request.n
            logprobs *= request.n
        return contents, logprobs

    def value(self, session_id: str, request: ChatRequest) -> float:
        session = self._activate(session_id)
        torch = self.torch
        self.model.eval()
        encoded = self._encoded_prompt(request)
        with torch.no_grad():
            output = self.model(**encoded, output_hidden_states=True, return_dict=True)
            hidden = output.hidden_states[-1][:, -1, :].float()
            score = session.value_head(hidden).squeeze().item()
        return float(score)

    def initial_equivalence_error(self, session_id: str, prompt: str) -> float:
        """Maximum logit delta between a fresh adapter and the frozen base."""
        self._activate(session_id)
        torch = self.torch
        encoded = self.tokenizer(prompt, return_tensors="pt").to(self.device)
        self.model.eval()
        with torch.no_grad():
            adapted = self.model(**encoded, return_dict=True).logits.float()
            with self.model.disable_adapter():
                reference = self.model(**encoded, return_dict=True).logits.float()
        return float((adapted - reference).abs().max().cpu())

    def _require_finite(self, value: Any, label: str) -> None:
        """Check session tensors without copying the shared base model."""
        if self.torch.is_tensor(value):
            if not bool(self.torch.isfinite(value).all().item()):
                raise FloatingPointError(f"non-finite {label}")
        elif isinstance(value, dict):
            for key, item in value.items():
                self._require_finite(item, f"{label}.{key}")
        elif isinstance(value, (list, tuple)):
            for index, item in enumerate(value):
                self._require_finite(item, f"{label}[{index}]")
        elif isinstance(value, float) and not math.isfinite(value):
            raise FloatingPointError(f"non-finite {label}")

    def learn(self, session_id: str, event: dict[str, Any]) -> BackendLearnResult:
        session = self._activate(session_id)
        torch = self.torch
        reward = float(event.get("reward", 0.0))
        if not math.isfinite(reward) or not -1.0 <= reward <= 1.0:
            raise ValueError("reward must be finite and in [-1, 1]")
        if reward > 0 and not bool(event.get("terminal_verified", event.get("root_verified", False))):
            raise ValueError("positive reward requires terminal_verified=true")
        prompt = event.get("prompt")
        target = str(event.get("tactic") or "")
        if not isinstance(prompt, str) or not prompt.strip() or not target:
            raise ValueError("training event requires the original inference prompt and a non-empty tactic")
        prompt_ids = self.tokenizer(prompt, return_tensors="pt")["input_ids"].to(self.device)
        target_ids = self.tokenizer(target, return_tensors="pt", add_special_tokens=False)["input_ids"].to(self.device)
        if not prompt_ids.numel() or not target_ids.numel():
            raise ValueError("training prompt and tactic must each encode at least one token")
        input_ids = torch.cat((prompt_ids, target_ids), dim=1)
        labels = torch.full_like(input_ids, -100)
        labels[:, prompt_ids.shape[1]:] = target_ids

        session.optimizer.zero_grad(set_to_none=True)
        previous_use_cache = self.model.config.use_cache
        try:
            self.model.config.use_cache = False
            self.model.train()
            session.value_head.train()
            output = self.model(
                input_ids=input_ids,
                labels=labels,
                output_hidden_states=True,
                return_dict=True,
            )
            token_nll = output.loss.float()
            policy_loss = reward * token_nll
            current_logits = output.logits[:, prompt_ids.shape[1] - 1:-1, :].float()
            with torch.no_grad(), self.model.disable_adapter():
                reference = self.model(input_ids=input_ids, return_dict=True)
                reference_logits = reference.logits[:, prompt_ids.shape[1] - 1:-1, :].float()
            current_log_probs = self.functional.log_softmax(current_logits, dim=-1)
            reference_log_probs = self.functional.log_softmax(reference_logits, dim=-1)
            kl = self.functional.kl_div(
                reference_log_probs,
                current_log_probs.exp(),
                reduction="batchmean",
            ) / max(1, target_ids.numel())
            value_hidden = output.hidden_states[-1][:, prompt_ids.shape[1] - 1, :].float()
            value_prediction = session.value_head(value_hidden).squeeze()
            value_target = torch.tensor(reward, device=self.device, dtype=torch.float32)
            value_loss = self.functional.mse_loss(value_prediction, value_target)
            loss = policy_loss + self.kl_beta * kl + self.value_coefficient * value_loss
            self._require_finite({
                "total": loss, "policy": policy_loss, "value": value_loss, "kl": kl,
            }, "loss")
            loss.backward()
            parameters = self._adapter_parameters(session_id) + list(session.value_head.parameters())
            self._require_finite([parameter.grad for parameter in parameters if parameter.grad is not None], "gradient")
            grad_norm = torch.nn.utils.clip_grad_norm_(
                parameters, self.max_grad_norm, error_if_nonfinite=True,
            )
            session.optimizer.step()
            # An optimizer can fail after modifying only some tensors. Runtime
            # owns the pre-step snapshot and rolls back any exception here.
            self._require_finite(parameters, "parameter")
            self._require_finite(session.optimizer.state_dict(), "optimizer")
        finally:
            self.model.config.use_cache = previous_use_cache
            self.model.eval()
            session.value_head.eval()
            session.optimizer.zero_grad(set_to_none=True)
        session.optimizer_steps += 1
        session.examples_seen += 1
        detail = {
            "loss": float(loss.detach().cpu()),
            "policy_loss": float(policy_loss.detach().cpu()),
            "value_loss": float(value_loss.detach().cpu()),
            "kl": float(kl.detach().cpu()),
            "reward": reward,
            "grad_norm": float(grad_norm.detach().cpu()),
            "finite_loss": True,
            "finite_gradients": True,
            "finite_parameters": True,
            "finite_optimizer_state": True,
            "optimizer_steps": session.optimizer_steps,
        }
        return BackendLearnResult(
            adapter_metadata={"kind": "lora", "rank": self.lora_config.r, "examples_seen": session.examples_seen},
            value_metadata={"hidden_size": self.hidden_size, "last_loss": detail["value_loss"]},
            optimizer_metadata={"kind": "AdamW", "steps": session.optimizer_steps},
            detail=detail,
        )

    def export_session(self, session_id: str) -> dict[str, Any]:
        session = self._activate(session_id)
        payload = {
            "adapter": self.get_peft_model_state_dict(self.model, adapter_name=session_id),
            "value_head": session.value_head.state_dict(),
            "optimizer": session.optimizer.state_dict(),
            "optimizer_steps": session.optimizer_steps,
            "examples_seen": session.examples_seen,
            "rng": {
                "seed": session.rng_seed, "device_type": self.device.type,
                "cpu": session.cpu_rng_state, "device": session.device_rng_state,
            },
        }
        buffer = io.BytesIO()
        self.torch.save(payload, buffer)
        return {
            "schema_version": "reap.gpu.real-prover-backend.v1",
            "encoding": "torch-save-base64",
            "payload": base64.b64encode(buffer.getvalue()).decode("ascii"),
        }

    def import_session(self, session_id: str, state: dict[str, Any]) -> None:
        session = self._activate(session_id)
        if state.get("schema_version") != "reap.gpu.real-prover-backend.v1":
            raise ValueError("unsupported REAL-Prover backend snapshot schema")
        raw = base64.b64decode(str(state.get("payload", "")), validate=True)
        payload = self.torch.load(io.BytesIO(raw), map_location=self.device, weights_only=True)
        rng = payload.get("rng")
        if not isinstance(rng, dict) or rng.get("device_type") != self.device.type:
            raise ValueError("snapshot requires matching per-session RNG state")
        cpu_state = rng["cpu"].cpu()
        # Validate RNG bytes using private generators before mutating any state.
        self.torch.Generator(device="cpu").set_state(cpu_state)
        device_state = rng.get("device")
        if self.device.type == "cuda":
            if device_state is None:
                raise ValueError("snapshot is missing device RNG state")
            device_state = device_state.cpu()
            self.torch.Generator(device=self.device).set_state(device_state)
        self._require_finite(payload, "snapshot")
        self.set_peft_model_state_dict(self.model, payload["adapter"], adapter_name=session_id)
        session.value_head.load_state_dict(payload["value_head"])
        session.optimizer.load_state_dict(payload["optimizer"])
        session.optimizer_steps = int(payload["optimizer_steps"])
        session.examples_seen = int(payload["examples_seen"])
        session.rng_seed = int(rng["seed"])
        session.cpu_rng_state = cpu_state.clone()
        session.device_rng_state = None if device_state is None else device_state.clone()
