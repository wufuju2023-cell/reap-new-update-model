"""High-level session, OpenAI Chat, learn, and snapshot orchestration."""

from __future__ import annotations

from copy import deepcopy
import hashlib
import json
from pathlib import Path
from typing import Any

from .actor import GpuActor
from .backend import Backend
from .errors import EventConflictError, VersionConflictError
from .identifiers import validate_identifier
from .schemas import chat_response, parse_chat_request, value_chat_response
from .session_store import SessionState, SessionStore
from .snapshot_store import SnapshotStore


def _event_digest(event: dict[str, Any]) -> str:
    try:
        encoded = json.dumps(event, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode(
            "utf-8"
        )
    except (TypeError, ValueError) as exc:
        raise ValueError("learn event must be finite JSON data") from exc
    return hashlib.sha256(encoded).hexdigest()


class GpuRuntime:
    def __init__(
        self,
        *,
        backend: Backend,
        snapshot_root: Path,
        actor: GpuActor | None = None,
        sessions: SessionStore | None = None,
    ) -> None:
        self.backend = backend
        self.actor = actor or GpuActor()
        self.sessions = sessions or SessionStore()
        self.snapshots = SnapshotStore(snapshot_root)
        self._unusable_sessions: set[str] = set()

    def _ensure_usable(self, session_id: str) -> None:
        if session_id in self._unusable_sessions:
            raise RuntimeError(
                f"session {session_id} is quarantined after failed rollback; delete and recreate it"
            )

    def _rollback(self, session_id: str, backend_state: dict[str, Any], session_state: dict[str, Any]) -> None:
        try:
            self.backend.import_session(session_id, backend_state)
            self.sessions.replace_locked(session_id, SessionState.from_snapshot(session_state))
        except BaseException as exc:
            # The policy version cannot describe partially restored parameters.
            # Keep other sessions available, but never serve this one again.
            self._unusable_sessions.add(session_id)
            raise RuntimeError(f"rollback failed for session {session_id}; session quarantined") from exc

    def create_session(self, session_id: str) -> dict[str, Any]:
        session_id = validate_identifier(session_id, kind="session_id")

        def operation() -> dict[str, Any]:
            metadata = self.backend.create_session(session_id)
            try:
                state = self.sessions.create(session_id, metadata)
            except BaseException:
                self.backend.delete_session(session_id)
                raise
            return state.snapshot()

        return self.actor.submit(operation)

    def delete_session(self, session_id: str) -> None:
        session_id = validate_identifier(session_id, kind="session_id")

        def operation() -> None:
            with self.sessions.locked(session_id):
                self.backend.delete_session(session_id)
                self.sessions.delete(session_id)
                self._unusable_sessions.discard(session_id)

        self.actor.submit(operation)

    def policy(self, session_id: str, raw_request: dict[str, Any]) -> dict[str, Any]:
        request = parse_chat_request(raw_request)

        def operation() -> dict[str, Any]:
            with self.sessions.locked(session_id) as state:
                self._ensure_usable(session_id)
                contents, logprobs = self.backend.policy(session_id, request)
                if len(contents) != request.n or len(logprobs) != request.n:
                    raise RuntimeError("backend returned the wrong number of policy choices")
                return chat_response(
                    model=request.model,
                    contents=contents,
                    token_logprobs=logprobs if request.logprobs else None,
                    policy_version=state.policy_version,
                )

        return self.actor.submit(operation)

    def value(self, session_id: str, raw_request: dict[str, Any]) -> dict[str, Any]:
        request = parse_chat_request(raw_request)

        def operation() -> dict[str, Any]:
            with self.sessions.locked(session_id) as state:
                self._ensure_usable(session_id)
                score = self.backend.value(session_id, request)
                return value_chat_response(model=request.model, score=score, policy_version=state.policy_version)

        return self.actor.submit(operation)

    def learn(self, session_id: str, *, expected_policy_version: int, event: dict[str, Any]) -> dict[str, Any]:
        if not isinstance(expected_policy_version, int) or isinstance(expected_policy_version, bool) or expected_policy_version < 0:
            raise ValueError("expected_policy_version must be a non-negative integer")
        if not isinstance(event, dict):
            raise ValueError("event must be an object")
        event_id = validate_identifier(event.get("event_id"), kind="event_id")
        digest = _event_digest(event)

        def operation() -> dict[str, Any]:
            with self.sessions.locked(session_id) as state:
                self._ensure_usable(session_id)
                receipt = state.event_receipts.get(event_id)
                if receipt is not None:
                    if receipt.get("digest") != digest:
                        raise EventConflictError(f"event_id reused with different payload: {event_id}")
                    response = deepcopy(receipt["response"])
                    response["applied"] = False
                    response["idempotent"] = True
                    return response
                if state.policy_version != expected_policy_version:
                    raise VersionConflictError(
                        f"stale policy_version for {session_id}: expected {expected_policy_version}, current {state.policy_version}"
                    )
                old_session = state.snapshot()
                # Backend snapshots contain only this session's mutable state,
                # not the shared frozen base. Snapshot before any mutation.
                old_backend = self.backend.export_session(session_id)
                try:
                    state.buffer_metadata.setdefault("events", {})[event_id] = {
                        "digest": digest,
                        "status": "pending",
                        "policy_version": expected_policy_version,
                    }
                    state.buffer_metadata.setdefault("pending_event_ids", []).append(event_id)
                    result = self.backend.learn(session_id, event)
                    # Reject invalid/NaN diagnostics before committing a version
                    # or receipt, including a backend that mutated then returned
                    # an invalid result instead of raising an exception.
                    json.dumps({
                        "adapter": result.adapter_metadata,
                        "value": result.value_metadata,
                        "optimizer": result.optimizer_metadata,
                        "detail": result.detail,
                    }, allow_nan=False)
                    state.policy_version += 1
                    state.adapter_metadata = deepcopy(result.adapter_metadata)
                    state.value_metadata = deepcopy(result.value_metadata)
                    state.optimizer_metadata = deepcopy(result.optimizer_metadata)
                    state.buffer_metadata["events"][event_id]["status"] = "consumed"
                    state.buffer_metadata["pending_event_ids"].remove(event_id)
                    state.buffer_metadata.setdefault("consumed_event_ids", []).append(event_id)
                    response = {
                        "event_id": event_id,
                        "applied": True,
                        "idempotent": False,
                        "policy_version": state.policy_version,
                        "detail": deepcopy(result.detail),
                    }
                    state.event_receipts[event_id] = {"digest": digest, "response": deepcopy(response)}
                except BaseException:
                    self._rollback(session_id, old_backend, old_session)
                    raise
                return response

        return self.actor.submit(operation)

    def snapshot(self, session_id: str, name: str) -> Path:
        name = validate_identifier(name, kind="snapshot name")

        def operation() -> Path:
            with self.sessions.locked(session_id) as state:
                self._ensure_usable(session_id)
                return self.snapshots.create(
                    session_id,
                    name,
                    session_state=state.snapshot(),
                    backend_state=self.backend.export_session(session_id),
                )

        return self.actor.submit(operation)

    def restore(self, session_id: str, name: str) -> dict[str, Any]:
        name = validate_identifier(name, kind="snapshot name")
        raw_session, raw_backend = self.snapshots.load(session_id, name)
        restored = SessionState.from_snapshot(raw_session)
        if restored.session_id != session_id:
            raise ValueError("snapshot session id mismatch")

        def operation() -> dict[str, Any]:
            with self.sessions.locked(session_id) as current:
                self._ensure_usable(session_id)
                old_session = current.snapshot()
                old_backend = self.backend.export_session(session_id)
                try:
                    self.backend.import_session(session_id, raw_backend)
                    self.sessions.replace_locked(session_id, restored)
                except BaseException:
                    self._rollback(session_id, old_backend, old_session)
                    raise
                return restored.snapshot()

        return self.actor.submit(operation)

    def inspect_backend(self, session_id: str) -> dict[str, Any]:
        def operation() -> dict[str, Any]:
            self._ensure_usable(session_id)
            return self.backend.export_session(session_id)

        return self.actor.submit(operation)

    def close(self) -> None:
        self.actor.close()

    def __enter__(self) -> "GpuRuntime":
        return self

    def __exit__(self, *_: object) -> None:
        self.close()
