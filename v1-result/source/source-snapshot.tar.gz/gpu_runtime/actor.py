"""A single-worker FIFO actor for all mutable GPU operations."""

from __future__ import annotations

from dataclasses import dataclass, field
import queue
import threading
from typing import Any, Callable


@dataclass
class _WorkItem:
    function: Callable[[], Any]
    done: threading.Event = field(default_factory=threading.Event)
    result: Any = None
    error: BaseException | None = None


class GpuActor:
    """Serialize backend access even when HTTP/session callers are concurrent."""

    def __init__(self, *, name: str = "reap-gpu-actor") -> None:
        self._queue: queue.Queue[_WorkItem | None] = queue.Queue()
        self._metrics_guard = threading.Lock()
        self._active = 0
        self.max_active = 0
        self.completed = 0
        self._closed = False
        self._thread = threading.Thread(target=self._run, name=name, daemon=True)
        self._thread.start()

    def _run(self) -> None:
        while True:
            item = self._queue.get()
            try:
                if item is None:
                    return
                with self._metrics_guard:
                    self._active += 1
                    self.max_active = max(self.max_active, self._active)
                try:
                    item.result = item.function()
                except BaseException as exc:  # propagate the exact backend error to the caller
                    item.error = exc
                finally:
                    with self._metrics_guard:
                        self._active -= 1
                        self.completed += 1
                    item.done.set()
            finally:
                self._queue.task_done()

    def submit(self, function: Callable[[], Any]) -> Any:
        if self._closed:
            raise RuntimeError("GPU actor is closed")
        item = _WorkItem(function=function)
        self._queue.put(item)
        item.done.wait()
        if item.error is not None:
            raise item.error
        return item.result

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        self._queue.put(None)
        self._thread.join()

    def __enter__(self) -> "GpuActor":
        return self

    def __exit__(self, *_: object) -> None:
        self.close()
