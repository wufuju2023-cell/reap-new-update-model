"""Standard-library client adapters for the GPU runtime control plane."""

from __future__ import annotations

from dataclasses import asdict
import json
import math
from typing import Any
from urllib.error import HTTPError
from urllib.request import Request, urlopen

from .segmented_ttt import LearnRequest, LearnResult


class GpuHttpClient:
    def __init__(self, base_url: str, *, timeout_seconds: float = 30.0) -> None:
        self.base_url = base_url.rstrip("/")
        self.timeout_seconds = float(timeout_seconds)
        if not math.isfinite(self.timeout_seconds) or self.timeout_seconds <= 0:
            raise ValueError("HTTP timeout must be finite and positive")

    def _request(self, method: str, path: str, body: dict[str, Any] | None = None) -> dict[str, Any]:
        data = None if body is None else json.dumps(body, ensure_ascii=False, allow_nan=False).encode("utf-8")
        request = Request(
            self.base_url + path,
            data=data,
            method=method,
            headers={"Content-Type": "application/json"},
        )
        try:
            with urlopen(request, timeout=self.timeout_seconds) as response:
                payload = json.loads(response.read())
        except HTTPError as error:
            detail = error.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"GPU runtime HTTP {error.code}: {detail}") from error
        if not isinstance(payload, dict):
            raise RuntimeError("GPU runtime returned a non-object response")
        return payload

    def create_session(self, session_id: str) -> dict[str, Any]:
        return self._request("POST", f"/sessions/{session_id}", {})

    def snapshot(self, session_id: str, name: str) -> dict[str, Any]:
        return self._request("POST", f"/sessions/{session_id}/snapshot/v1", {"name": name})

    def restore(self, session_id: str, name: str) -> dict[str, Any]:
        return self._request("POST", f"/sessions/{session_id}/restore/v1", {"name": name})

    def delete_session(self, session_id: str) -> dict[str, Any]:
        return self._request("DELETE", f"/sessions/{session_id}")

    def learn(self, request: LearnRequest) -> LearnResult:
        version = request.policy_version
        acknowledged: list[str] = []
        details: list[dict[str, Any]] = []
        for event in request.events:
            payload = self._request(
                "POST",
                f"/sessions/{request.session_id}/learn/v1",
                {
                    "expected_policy_version": version,
                    "event": asdict(event),
                },
            )
            returned_id = payload.get("event_id")
            if returned_id != event.event_id:
                raise RuntimeError(f"GPU runtime acknowledged wrong event: {returned_id!r}")
            returned_version = payload.get("policy_version")
            if not isinstance(returned_version, int) or returned_version <= version:
                raise RuntimeError("GPU runtime did not advance policy_version")
            version = returned_version
            acknowledged.append(returned_id)
            details.append(payload)
        return LearnResult(
            policy_version=version,
            event_ids=tuple(acknowledged),
            metadata={"receipts": details},
        )

