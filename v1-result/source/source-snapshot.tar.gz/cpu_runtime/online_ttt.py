"""Coordinate in-search updates through the Lean observer's checkpoint barrier.

One process and one MCTS tree remain alive while LEARN runs.  No uncertain
mutation is retried, and no ACK permits continued search after a failed update.
"""
from __future__ import annotations

import argparse
from dataclasses import asdict
import hashlib
import json
import math
import os
from pathlib import Path
import signal
import subprocess
import time
from typing import Any, Callable

from .batch_solver import SessionSpec, SESSION_RE, _finalize_solver_status
from .http_clients import GpuHttpClient

OBJECTIVE = "search_visit_backup"
VALUE_SEMANTICS = "reap.search_backup_discounted_return.v1"
MAX_LEARN_BODY_BYTES = 8192  # Current authenticated browser transport contract.


def validate_created(created: dict[str, Any], session_id: str, gamma: float) -> None:
    metadata = created.get("value_metadata", {})
    if (created.get("session_id") != session_id or created.get("policy_version") != 0
            or metadata.get("objective") != OBJECTIVE or metadata.get("gamma") != gamma
            or metadata.get("value_semantics") != VALUE_SEMANTICS):
        raise ValueError("created session does not match strict objective/session/gamma/value semantics")


def validate_learn_receipt(receipt: dict[str, Any], event: dict[str, Any], version: int) -> None:
    if (receipt.get("event_id") != event["event_id"]
            or receipt.get("policy_version") != version + 1
            or receipt.get("applied") is not True or receipt.get("idempotent") is not False):
        raise ValueError("learn receipt identity/version/applied mismatch")
    detail = receipt.get("detail", {})
    if detail.get("objective") != OBJECTIVE or detail.get("optimizer_steps") != version + 1:
        raise ValueError("learn receipt objective/optimizer step mismatch")
    for flag in ("finite_loss", "finite_gradients", "finite_parameters", "finite_optimizer_state", "base_parameters_frozen"):
        if detail.get(flag) is not True:
            raise ValueError(f"learn receipt missing successful {flag} gate")
    for key in ("loss", "policy_loss", "kl", "value_loss", "grad_norm", "value_target"):
        value = detail.get(key)
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
            raise ValueError(f"learn receipt nonfinite/missing {key}")
    trace = detail.get("search_trace", {})
    for key in ("tree_id", "step", "node_index", "policy_version", "gamma", "terminal_verified"):
        if trace.get(key) != event[key]:
            raise ValueError(f"learn receipt source mismatch: {key}")
    if detail.get("prompt_sha256") != hashlib.sha256(event["prompt"].encode()).hexdigest():
        raise ValueError("learn receipt prompt hash mismatch")
    diffs = detail.get("parameter_diffs", {})
    for group in ("adapter", "value_head", "optimizer"):
        item = diffs.get(group, {})
        if (item.get("before_sha256") == item.get("after_sha256")
                or item.get("changed_tensors", 0) + item.get("added_tensors", 0) <= 0):
            raise ValueError(f"learn receipt has no changed {group} update")


def validate_learn_body(version: int, event: dict[str, Any]) -> None:
    # Match GpuHttpClient's actual encoding, including spaces and UTF-8.
    body = json.dumps({"expected_policy_version": version, "event": event},
                      ensure_ascii=False, allow_nan=False).encode("utf-8")
    if len(event["candidates"]) > 64:
        raise ValueError("candidate count exceeds 64; never truncate the visit distribution")
    if len(body) > MAX_LEARN_BODY_BYTES:
        raise ValueError("learn body exceeds browser transport 8192-byte limit; never truncate")


def json_bytes(value: Any) -> bytes:
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, allow_nan=False) + "\n").encode()


def atomic_new_json(path: Path, value: Any) -> None:
    """Publish a new ACK/result in an owned directory; never replace evidence."""
    if path.exists() or path.is_symlink():
        raise FileExistsError(path)
    temporary = path.with_name(path.name + f".tmp-{os.getpid()}")
    with temporary.open("xb") as handle:
        handle.write(json_bytes(value))
        handle.flush()
        os.fsync(handle.fileno())
    if path.exists():
        raise FileExistsError(path)
    os.rename(temporary, path)


class JsonlTail:
    """Consume only complete flushed records, retaining a partial final line."""
    def __init__(self, path: Path):
        self.path, self.offset, self.pending = path, 0, b""

    def read(self) -> list[dict[str, Any]]:
        if not self.path.exists():
            return []
        with self.path.open("rb") as handle:
            if self.path.stat().st_size < self.offset:
                raise ValueError("observer file was truncated")
            handle.seek(self.offset)
            data = handle.read()
        self.offset += len(data)
        lines = (self.pending + data).split(b"\n")
        self.pending = lines.pop()
        return [json.loads(line) for line in lines if line.strip()]


class OnlineCoordinator:
    def __init__(self, session_id: str, tree_id: str, ack_dir: Path,
                 learn: Callable[[int, dict[str, Any]], dict[str, Any]], *,
                 gamma: float, max_updates: int = 5):
        if not SESSION_RE.fullmatch(session_id) or not SESSION_RE.fullmatch(tree_id):
            raise ValueError("invalid session/tree id")
        if not math.isfinite(gamma) or not 0 < gamma < 1 or max_updates < 1:
            raise ValueError("invalid gamma/update budget")
        self.session_id, self.tree_id = session_id, tree_id
        self.ack_dir, self.learn, self.gamma = ack_dir, learn, gamma
        self.max_updates, self.version, self.next_sequence = max_updates, 0, 0
        self.last_step = -1
        self.generated: dict[tuple[int, int, int, int], dict[str, Any]] = {}
        self.edge_sources: dict[tuple[int, str], dict[str, Any]] = {}
        self.backed_up_nodes: set[int] = set()
        self.consumed_stats: dict[int, tuple[Any, ...]] = {}
        self.receipts: list[dict[str, Any]] = []
        self.requests: list[dict[str, Any]] = []
        self.post_update_generations: list[dict[str, Any]] = []
        self.ack_dir.mkdir(parents=True, exist_ok=False)

    def _validate(self, record: dict[str, Any]) -> None:
        if record.get("schema_version") != "reap.training.observer.v1":
            raise ValueError("unknown observer schema")
        if record.get("session_id") != self.session_id or record.get("tree_id") != self.tree_id:
            raise ValueError("observer session/tree mismatch")
        if record.get("sequence") != self.next_sequence:
            raise ValueError("observer sequence gap or replay")
        self.next_sequence += 1
        if record.get("policy_version") != self.version:
            raise ValueError("observer policy version mismatch")

    def _target(self, record: dict[str, Any]) -> tuple[dict[str, Any], tuple[Any, ...]] | None:
        gamma = record.get("gamma")
        if not isinstance(gamma, (int, float)) or isinstance(gamma, bool) or not math.isclose(gamma, self.gamma, rel_tol=0, abs_tol=1e-12):
            raise ValueError("Lean and trainer gamma mismatch")
        if record.get("root_is_solved"):
            # This is only a search flag; final root replay has not happened.
            return None
        nodes = record["tree"]["nodes"]
        for node_index in sorted(self.backed_up_nodes, reverse=True):
            node = nodes[node_index]
            data = node["data"]
            count, total = data.get("numVisit"), data.get("valueSum")
            if data.get("toPlay") != "OR" or data.get("isSolved"):
                continue
            if not isinstance(count, int) or isinstance(count, bool) or count <= 0:
                continue
            if not isinstance(total, (int, float)) or not math.isfinite(total) or total / count > -1:
                continue  # unvisited/default/sentinel is not a value target
            candidates, prompts = [], set()
            for child in node.get("children", []):
                edge = child["edge"]
                if edge.get("isFocus"):
                    continue
                tactic = edge.get("tacticStr")
                source = self.edge_sources.get((node_index, tactic))
                if source is None:
                    raise ValueError("tree candidate has no generation provenance")
                if source["child_index"] != child["childIndex"]:
                    raise ValueError("tree edge child differs from its original eval provenance")
                prompts.add(source["prompt"])
                candidates.append({"tactic": tactic, "visits": edge["numVisit"],
                    "raw_logprob": source["raw_logprob"],
                    "behavior_version": source["policy_version"]})
            if not candidates or sum(item["visits"] for item in candidates) == 0:
                continue
            if len(prompts) != 1:
                raise ValueError("one search target mixes inference prompts")
            stats = (count, total, tuple((c["tactic"], c["visits"]) for c in candidates))
            if self.consumed_stats.get(node_index) == stats:
                continue
            event = {"kind": "search_visit_backup", "event_id": f"{self.session_id}.s{record['step']}.n{node_index}",
                "session_id": self.session_id, "tree_id": self.tree_id,
                "step": record["step"], "node_index": node_index,
                "policy_version": self.version, "prompt": next(iter(prompts)),
                "gamma": self.gamma, "candidates": candidates,
                "backup": {"value_sum": total, "visits": count, "kind": "OR", "valid": True},
                "reward": 0, "terminal_verified": False}
            if not SESSION_RE.fullmatch(event["event_id"]):
                raise ValueError("event id exceeds protocol limit")
            return event, stats
        return None

    def accept(self, record: dict[str, Any]) -> None:
        self._validate(record)
        kind = record.get("kind")
        if kind == "generation":
            identity = tuple(record[k] for k in ("step", "node_index", "generation_index", "candidate_index"))
            if identity in self.generated:
                raise ValueError("duplicate generation identity")
            self.generated[identity] = record
            if self.version > 0:
                self.post_update_generations.append({k: record[k] for k in
                    ("sequence", "step", "node_index", "policy_version", "tree_id")})
        elif kind == "eval":
            identity = tuple(record[k] for k in ("step", "node_index", "generation_index", "candidate_index"))
            source = self.generated.pop(identity, None)
            if source is None or source["tactic"] != record["tactic"]:
                raise ValueError("eval does not match an observed generation")
            if record["disposition"] == "created":
                key = (record["node_index"], record["tactic"])
                if key in self.edge_sources or record.get("child_index") is None:
                    raise ValueError("invalid created edge provenance")
                self.edge_sources[key] = {**source, "child_index": record["child_index"]}
            # A merged duplicate/alias increments the original core edge prior,
            # not its visit count; keep that edge's FIRST creator provenance.
            elif record["disposition"] not in ("merged", "eval_rejected", "ancestor_rejected"):
                raise ValueError("unknown eval disposition")
        elif kind == "backup":
            self.backed_up_nodes.add(record["node_index"])
        elif kind == "checkpoint":
            step = record["step"]
            if step != self.last_step + 1:
                raise ValueError("checkpoint step gap/replay")
            self.last_step = step
            ack = {"session_id": self.session_id, "step": step,
                   "status": "continue", "policy_version": self.version}
            path = self.ack_dir / f"checkpoint-{step:06d}.ack.json"
            try:
                target = self._target(record)
                if target is not None and len(self.receipts) < self.max_updates:
                    event, stats = target
                    validate_learn_body(self.version, event)
                    self.requests.append(event)
                    # Persist intent before the mutation; never resubmit on a timeout.
                    atomic_new_json(self.ack_dir / f"learn-{step:06d}.request.json", event)
                    receipt = self.learn(self.version, event)
                    validate_learn_receipt(receipt, event, self.version)
                    atomic_new_json(self.ack_dir / f"learn-{step:06d}.receipt.json", receipt)
                    self.version += 1
                    self.receipts.append(receipt)
                    self.consumed_stats[event["node_index"]] = stats
                    ack["policy_version"] = self.version
            except BaseException as exc:
                ack.update(status="error", error=f"{type(exc).__name__}: {exc}")
                atomic_new_json(path, ack)
                raise
            atomic_new_json(path, ack)
            self.backed_up_nodes.clear()


def _stop_owned_process(process: subprocess.Popen) -> None:
    if process.poll() is not None:
        return
    if os.name == "nt":
        subprocess.run(["taskkill", "/PID", str(process.pid), "/T", "/F"],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
    else:
        os.killpg(process.pid, signal.SIGTERM)
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        if os.name != "nt":
            os.killpg(process.pid, signal.SIGKILL)
        else:
            process.kill()
        process.wait()


def run_online(*, session_id: str, project_dir: Path, theorem_file: str,
               output_root: Path, gpu_base_url: str, gamma: float,
               max_updates: int = 5, http_timeout: float = 720,
               barrier_timeout: int = 900, lean_bin: str = "lake",
               client: GpuHttpClient | None = None,
               command: list[str] | None = None) -> dict[str, Any]:
    if not SESSION_RE.fullmatch(session_id) or len(session_id) > 40:
        raise ValueError("online session id must be valid and at most 40 characters")
    project_dir, output_root = project_dir.resolve(), output_root.resolve()
    theorem_path = Path(theorem_file)
    if not theorem_path.is_absolute():
        theorem_path = project_dir / theorem_path
    theorem_sha = hashlib.sha256(theorem_path.read_bytes()).hexdigest()
    directory = output_root / session_id
    directory.mkdir(parents=True, exist_ok=False)
    tree_id = session_id + ".tree0"
    spec = SessionSpec(session_id, str(theorem_path),
        f"{gpu_base_url}/sessions/{session_id}/policy/v1",
        f"{gpu_base_url}/sessions/{session_id}/value/v1")
    atomic_new_json(directory / "session.json", {**asdict(spec),
        "profile": "online-search-visit-backup-v1", "tree_id": tree_id,
        "theorem_sha256": theorem_sha, "gamma": gamma,
        "max_updates": max_updates, "total_deadline_seconds": None})
    client = client or GpuHttpClient(gpu_base_url, timeout_seconds=http_timeout)

    def learn(version: int, event: dict[str, Any]) -> dict[str, Any]:
        return client._request("POST", f"/sessions/{session_id}/learn/v1",
                               {"expected_policy_version": version, "event": event})

    coordinator = OnlineCoordinator(session_id, tree_id, directory / "checkpoints",
                                    learn, gamma=gamma, max_updates=max_updates)
    created = client.create_session(session_id)
    atomic_new_json(directory / "create-receipt.json", created)
    validate_created(created, session_id, gamma)
    atomic_new_json(directory / "snapshot-before.json", client.snapshot(session_id, "before-online-ttt"))
    env = os.environ.copy()
    env.update({"REAP_SESSION_ID": session_id, "REAP_SESSION_DIR": str(directory),
        "REAP_TREE_ID": tree_id, "REAP_POLICY_VERSION": "0",
        "REAP_POLICY_ENDPOINT": spec.policy_base_url,
        "REAP_VALUE_ENDPOINT": spec.value_base_url, "REAP_PS_ENDPOINT": "",
        "REAP_OBSERVER_PATH": str(directory / "observer.jsonl"),
        "REAP_CHECKPOINT_DIR": str(coordinator.ack_dir),
        "REAP_CHECKPOINT_TIMEOUT_SECONDS": str(barrier_timeout)})
    options: dict[str, Any] = {"creationflags": subprocess.CREATE_NEW_PROCESS_GROUP} if os.name == "nt" else {"start_new_session": True}
    start = time.monotonic()
    error = None
    tail = JsonlTail(directory / "observer.jsonl")
    with (directory / "stdout.log").open("xb") as stdout, (directory / "stderr.log").open("xb") as stderr:
        process = subprocess.Popen(command or [lean_bin, "env", "lean", str(theorem_path)],
            cwd=project_dir, env=env, stdout=stdout, stderr=stderr, **options)
        atomic_new_json(directory / "process.json", {"pid": process.pid,
            "command": command or [lean_bin, "env", "lean", str(theorem_path)],
            "tree_id": tree_id, "started_at_epoch": time.time()})
        try:
            while True:
                for event in tail.read():
                    coordinator.accept(event)
                if process.poll() is not None:
                    for event in tail.read():
                        coordinator.accept(event)
                    if tail.pending.strip():
                        raise ValueError("incomplete final observer record")
                    break
                time.sleep(0.02)
        except BaseException as exc:
            error = {"type": type(exc).__name__, "message": str(exc),
                     "mutation_retry_allowed": False}
            _stop_owned_process(process)
    solved, status = _finalize_solver_status(directory / "result.json", process.returncode, False)
    exercised = bool(coordinator.receipts and coordinator.post_update_generations)
    report = {"session_id": session_id, "tree_id": tree_id, "lean_pid": process.pid,
        "profile": "online-search-visit-backup-v1", "returncode": process.returncode,
        "root_verified": bool(solved and error is None),
        "online_update_consumed_by_later_generation": exercised,
        "status": "passed_execution" if solved and exercised and error is None else
                  ("solved_without_online_update" if solved and error is None else status),
        "policy_version": coordinator.version, "optimizer_updates": len(coordinator.receipts),
        "checkpoint_count": coordinator.last_step + 1,
        "elapsed_seconds": time.monotonic() - start,
        "post_update_generations": coordinator.post_update_generations,
        "learn_receipts": coordinator.receipts, "error": error,
        "total_deadline_seconds": None,
        "note": "Execution gate only; independently audit wire versions, parameter changes and final proof."}
    # Snapshot only after all known mutations returned; an unknown outcome is
    # not repaired by further mutations or by starting the experiment again.
    if error is None:
        atomic_new_json(directory / "snapshot-after.json", client.snapshot(session_id, "after-online-ttt"))
    atomic_new_json(directory / "online-result.json", report)
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--session-id", required=True)
    parser.add_argument("--project-dir", type=Path, required=True)
    parser.add_argument("--theorem-file", required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--gpu-base-url", required=True)
    parser.add_argument("--gamma", type=float, required=True)
    parser.add_argument("--max-updates", type=int, default=5)
    parser.add_argument("--http-timeout-seconds", type=float, default=720)
    parser.add_argument("--barrier-timeout-seconds", type=int, default=900)
    parser.add_argument("--lean-bin", default="lake")
    args = parser.parse_args()
    if not math.isfinite(args.gamma) or not 0 < args.gamma < 1:
        parser.error("gamma must be finite and strictly between zero and one")
    if args.max_updates < 1 or args.barrier_timeout_seconds < 1:
        parser.error("update budget and barrier timeout must be positive")
    report = run_online(session_id=args.session_id, project_dir=args.project_dir,
        theorem_file=args.theorem_file, output_root=args.output_dir,
        gpu_base_url=args.gpu_base_url.rstrip("/"), gamma=args.gamma,
        max_updates=args.max_updates, http_timeout=args.http_timeout_seconds,
        barrier_timeout=args.barrier_timeout_seconds, lean_bin=args.lean_bin)
    print(json.dumps(report, ensure_ascii=False, allow_nan=False))
    return 0 if report["status"] == "passed_execution" else 2


if __name__ == "__main__":
    raise SystemExit(main())
