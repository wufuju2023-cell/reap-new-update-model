# A/B Docker 构建材料

本目录提供两份独立镜像的构建与运行入口，参考新 `docker@fc25669…` 的职责划分，保留现有更完整的多 session、same-tree、版本/恢复实现。**本次新增 recipe 尚未 build/run，B 未发布；不能把宿主 GPU 成功写成 GPU 容器成功。** 实验结果见 [结果文档](../docs/README.md)。本目录所有 Markdown 均留在子目录内。

## 内容与已验边界

| 文件 | 用途 |
|---|---|
| [cpu.Dockerfile](cpu.Dockerfile) | 复制现有 A 构建链，固定 Reap commit/Lean 基础 digest，使用预编译 Lean 和 Mathlib cache，依序应用 0001/0002/0003；增加正式 Square/Geometric 题目 |
| [train.Dockerfile](train.Dockerfile) | 固定 ROCm/PyTorch 基础 digest、22 包 wheel hash、REAL-Prover revision/官方 manifest；`release-existing` 和最终 `release` 均默认 `real-search --gamma 0.99` |
| [prepare_context.py](prepare_context.py) | 调用原受控 context helper，只替换新 context 的 `containers/gpu/Containerfile`，更新 recipe 文件哈希和总清单，嵌入原清单作为溯源，再逐文件复核 |
| [build.sh](build.sh)、[run-cpu.sh](run-cpu.sh)、[run-gpu.sh](run-gpu.sh) | Linux/WSL 模板；默认 Podman，`CONTAINER_ENGINE=docker` 可切换 |
| [test_delivery_context.py](test_delivery_context.py) | 微型合成 safetensors 验证封装/篡改/不覆盖门禁，不是模型或容器测试 |

原实验 A 镜像已实跑：`localhost/reap-cpu:v1-online-recurrence`，ID `df23cd6a9b5b6df30fa003285fadcdc1e5d60919eb43b823b0731c17bf135646`。它是已验层的增量镜像；**不等于本目录新 cpu.Dockerfile 已从零构建通过**。新 recipe 不自动获得旧镜像的验收身份。源文件/recipe 摘要见 [materials-sha256.json](materials-sha256.json)。

当前阻塞：当前 ModelScope 实例 UID=0，但 `CAP_SYS_ADMIN=false`、seccomp=0，Docker 无法连接，三个候选 socket 均不存在，Podman 当前未安装。此前另一个实例安装过 Podman，但运行时挂载 proc 被拒绝、exit 126；不能把旧实例的安装状态写成当前状态，也不能把 root 或 seccomp=0 当成已获二级容器权限。已验宿主 Torch 2.11 与候选容器 Torch 2.10 不是同一环境，B 必须重新验证 HIP、真实模型、数值/隔离/恢复和最终 Lean TTT。完整依赖/SBOM、发布目标和可见性仍待确认。

## 构建

使用完整仓库作为 A context，不是仅复制本目录。以下在仓库根目录执行；需要可信网络取得固定基础镜像、APT 和源码，Lean 本体不从源码编译：

```bash
bash v1-result/docker/build.sh cpu localhost/reap-cpu:v1-delivery
```

B 只在用户授权、具备合法容器 builder 且能访问既有模型的**远端**执行。权重始终留在远端，不下载本机；复制受控 context 需要约额外 15.25GB 空间，构建层还需更多。`--authorized-remote-builder`/环境标记只是防误操作提示，不授予平台权限。

```bash
export AUTHORIZED_REMOTE_BUILDER=yes
model_dir=/mnt/workspace/models/REAL-Prover-fe76f68d
manifest=/mnt/workspace/reap-v1-20260827-gpu/model-manifest.json
new_context='/mnt/workspace/replace-with-new-build-context'
bash v1-result/docker/build.sh gpu-existing localhost/reap-gpu:v1-delivery \
  "$model_dir" "$manifest" \
  b20526a1d3a08365893fe937dfdec4b1d953b8c63f26cc89e922c962c11f3915 "$new_context"
```

模型/manifest 路径为本次实例示例，先核对；`new_context` 必须不存在。原 helper 校验官方文件哈希、safetensors 索引和张量，再生成只含 GPU 源码/依赖/模型的白名单 context。wrapper 保留全部原模型/锁文件条目及官方 manifest 字节；只修改新 context 中的 recipe 和其清单身份，不改仓库原 Dockerfile，不把私有配置、签名 URL、Git 或 CPU 源码放进 B。

本模板显式构建 `release-existing`，不会执行在线 `model-download` 阶段。新 recipe 的 `release` 虽也默认 strict backend，但会在线取权重，不是本次推荐复现路径。若准备中断，保留失败目录，换新目录核查后重做，不自动覆盖或清理。

## 容器运行与验收（待实测）

以下是**获授权的普通 AMD Linux 容器主机**模板，不代表当前 DSW 支持。单 GPU 服务保留私有 IPC，仅设置 `--shm-size 8g`；不使用 host IPC、privileged、cap-add 或安全策略绕过。DSW 官方禁止 `--ipc=host`，并对资源组、设备与挂载另有约束，不能把普通主机的设备/命名卷参数直接视为 DSW 可用。缺权限就停止，按平台支持方式处理。[阿里云 DSW Docker 限制](https://help.aliyun.com/zh/pai/using-docker-in-dsw)

```bash
export AUTHORIZED_GPU_RUNTIME=yes
bash v1-result/docker/run-gpu.sh localhost/reap-gpu:v1-delivery reap-b-new reap-b-new-out
```

该命令前台运行。另一个终端 `curl --fail http://127.0.0.1:8760/health`，核验 `backend=real-search`、实际 HIP 和服务状态；PID 存在或容器启动不算 GPU 验收。模型已烘焙，无需模型 bind mount，输出卷用于 snapshots。没有开放公网端口，也没有设置 API 身份认证；跨主机只能使用已授权的安全通道。

将 [batch.example.jsonl](batch.example.jsonl) 复制到新的文件，替换两个唯一 session ID。B ready 后，在同一 Linux 主机或已设置桥接的 CPU 主机运行：

```bash
bash v1-result/docker/run-cpu.sh localhost/reap-cpu:v1-delivery reap-a-new \
  /absolute/path/to/new-batch.jsonl reap-a-new-out http://127.0.0.1:8760
```

若用本地 Edge/OpenCLI bridge，替换 URL 为其 localhost 端口并先配置相同 session 白名单；不能直接套用历史实例 ID。保留容器日志、inspect、输出卷和 B 快照。样例 concurrency=2、gamma=0.99、最多5次更新；720/900秒是请求/屏障保护，**TTT 没有总 deadline**。CPU batch 的 `completed` 也可能包含提前解题但零更新结果；必须检查每路 `online_execution_gate_passed` 和独立证据，不能据此冒称 TTT。

最终需核对真实 Lean visit/backup→GPU 参数更新→同树后续版本消费→最终 proof、双 session 隔离及 wire/快照。原任务的 A/B 独立交付不因宿主通过而撤销；不自动 push。AMD 实例的启动和关闭全部由用户负责，自动空闲保护已暂停。

## 本地静态与微型检查

```bash
python3 v1-result/docker/test_delivery_context.py
for script in v1-result/docker/build.sh v1-result/docker/run-cpu.sh v1-result/docker/run-gpu.sh; do
  bash -n "$script"
done
```

本次 WSL 14 项测试全部通过；Windows 12 项通过、2 项因 symlink 权限跳过。三份 shell 分别通过 `bash -n`；日志及静态检查见 [checks](checks)。这里只测试受控 context 的封装逻辑和 shell 语法；不接触真实模型、不启动 AMD，也不证明 Dockerfile build 或 GPU 容器成功。

构建源码快照与逐文件校验见 [source](../source/README.md)。快照保留仓库根布局，不含权重、Git 历史或凭据，不是 OCI 镜像；单独解包后仍可找到原 helper。无 `.git` 的独立目录中 `git_state` 返回 `head=null`、`dirty=null`，不会伪称 clean；使用文件哈希确认源码身份。
