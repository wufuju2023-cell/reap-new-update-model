# 不含模型权重的GPU运行时镜像

`Containerfile.runtime` 是新增独立配方，保留原 `Containerfile` 的历史含权重交付方式。新配方不下载、不复制7B权重，模型、数据集和输出目录在运行时挂载。默认服务仍是 `real`；需要搜索、verified或mixed合同必须显式传原server参数。

## 本地已验证

2026-08-28在本地WSL、rootless Podman 4.9.3构建成功：

- 镜像：`localhost/reap-gpu:runtime-20260828`
- ID：`fc5687143dd7fd6ca276e45ed1d420fd3b611fa3299c42245216f94326c2dba3`
- digest：`sha256:ed6b3a035fcded94ce2c48653120d04aeb7bb7b57e9b49782ad3edd37943255d`
- 展开大小29,817,042,215字节；没有发布或上传。
- 构建26.680秒（不含约12分钟基础镜像拉取）；真实构建exit0。
- `--network=none --read-only` 容器实测exit0：UID10001、30个运行时/数据模块源码哈希、核心库imports、3个Toy session及2次终态snapshot复用退役、容量补位通过。
- 真实容器Torch为`2.10.0+rocm7.2.4.git3d3aa833`、HIP`7.2.53211`。本地没有GPU，`cuda_available=false`；没有实际模型加载、训练或GPU数值验收。

证据：仓库 `.downloads/gpu-runtime-image-local-20260828/`；`context-v2`为实际构建输入，manifest SHA为`21c75868d99d0b9c8e1a0657fe4edc1f38fa3e2c1d7ea964096eadd35fd7bf82`。`evidence/attempt-2`含构建及容器inspect/退出码。旧失败输入和日志保留。

## 可重复构建

准备工具只读取当前运行时源码和既有22个hash固定wheel，不访问模型目录、网络或容器服务。wheelhouse必须恰好满足固定锁，额外wheel、损坏、缺失、链接和已有输出目录均拒绝。

```bash
python -B -m tools.amd_jupyter.prepare_gpu_runtime_context \
  --wheelhouse /path/to/reviewed-gpu-wheels-cp312 \
  --output /path/to/new-runtime-context
podman pull docker.io/rocm/pytorch@sha256:4449f856653602317e4101a76fce599c7fcd58ccec2e539951fce5f73083179e
cd /path/to/new-runtime-context
podman build --network=none --pull=never --retry=0 --jobs=1 \
  -f containers/gpu/Containerfile.runtime -t localhost/reap-gpu:runtime-local .
```

基础镜像压缩层10,390,820,431字节，展开约29.54GB，构建前需预留磁盘；新运行时层约275MB。不包含本地7B下载。安装只使用`--no-index --require-hashes --no-deps`，独立`/opt/reap-python`覆盖层不替换基础Torch。为了兼容本地Buildah，安装脚本单独`COPY`后运行，不使用Dockerfile heredoc。

## 真实AMD容器仍待验收

运行需平台已授权、实际可用的容器服务及GPU设备映射。模型应先核验既有官方manifest，再只读挂到`/opt/models/REAL-Prover`；输出挂到`/workspace/out`且UID10001可写。不要把模型或数据复制回镜像层。混合profile还需显式数据集/learner store挂载和与来源完全一致的合同参数。

主任务当前实例只检测到Docker客户端，无法连接daemon，三个候选socket不存在、无Podman/Buildah且CAP_SYS_ADMIN=false；没有尝试绕过权限或安装daemon。本次宿主Torch2.11的成功实验不能替代候选容器Torch2.10的GPU验收。后续有合法容器服务时仍需加载真实7B、确认HIP设备、相同数值/状态隔离/恢复及挂载持久化；两镜像设计保留。
