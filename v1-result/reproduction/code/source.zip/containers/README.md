# REAP 双镜像布局

从仓库根目录独立构建两份 OCI 镜像：**A 负责 CPU Lean/Reap MCTS；B 负责远端 AMD GPU 推理与 TTT。** 两者通过 HTTP 协作，只共享 batch/out/adapter 数据，不互挂源码；改代码后重新构建。

## A：CPU 镜像（本机已验证）

本机 Windows 的 WSL2 Ubuntu / rootless Podman 可用。构建复用 [versions.lock](versions.lock) 中固定 digest 的 GHCR 预编译 Lean `v4.28.0-rc1`，位置为 `/opt/lean`；不通过 elan 安装，也不编译 Lean 编译器。

镜像另包含锁定 Reap、`Reap.Training` overlay、匹配的 Mathlib 二进制缓存、CPU runner 与运行时 HTTP 所需的 `curl`。默认用户 `reap` 的 UID 为 10001，避免与 Ubuntu 24.04 已有 UID 1000 冲突。

默认入口：`python3 -m cpu_runtime.batch_solver`。每条 manifest 使用独立 session ID、Lean 进程、输出目录和 `/sessions/<id>/...` policy/value 地址。独立 BatchSolver 的 300 秒默认值是单进程保护超时；TTT 总 deadline 默认不设，五分钟只是性能期望。

Linux / WSL 仓库根目录的构建命令：

```bash
podman build --layers -f containers/cpu/Containerfile -t localhost/reap-cpu:v1-rebuild .
```

PowerShell 完整构建、独立输出卷 smoke 与导出方法见[CPU 复现记录](../计划对齐与实践/可复用记录/04-CPU镜像构建与双Session.md)。2026-08-27 已验证：镜像成功、无外网/无 GPU/仅输出卷的两 Lean/Reap 进程并发、两 session 均 solved，批次 40.909422s。policy/value 为 mock，**不是 GPU TTT**。

上述双 session 来自前阶段 `v1`；`v1-prompt` 另完成真实 Lean + toy 分段闭环（56.220413s）。最新 `v1-bridge` 新增 `--http-timeout-seconds`，已独立完成两 CPU 容器→本地 bridge→47 个 detached worker→宿主 ToyBackend 的双 session 闭环（40.147s）：每 session 2 ACT/1 toy learn，版本 0→1 后 fresh-root 真 Lean 通过，snapshot/restore/delete 通过。它未用浏览器、远端或 GPU，神经参数更新数为 0；复现见[本地 bridge 步骤](../计划对齐与实践/可复用记录/07-开机前本地准备与部署包.md)。请求超时、ACT 超时和可选总 deadline 是三个独立配置。

随后同一精确 `v1-bridge` 镜像的两个 A 经 Edge/OpenCLI 接远端真实 7B 宿主，各完成正反馈 learn 一步、v0→v1 fresh-root 再证明，联合容器窗口 83.251837170s；见[历史分段 GPU TTT 复现](../计划对齐与实践/可复用记录/10-双session真实GPU-TTT.md)。该轮 15 条原始 HTTP wire 与训练后快照/实际张量补核已完成；无该轮训练前快照及新增 restore 验收。B 未容器化，不将宿主执行通过写成双镜像交付完成。

同树 observer/strict value 和正式递推题目的已验增量 A 为 `v1-online-recurrence`（ID `df23cd6a9b5b6df30fa003285fadcdc1e5d60919eb43b823b0731c17bf135646`）。可交付的新 A/B 构建材料见 [v1-result/docker](../v1-result/docker/README.md)；新 recipe 尚未从零 build/run，实际 TTT 结果与边界见[结果文档](../v1-result/docs/README.md)。新 Docker 资料仅参考，不要求替换现有更可靠实现。

镜像尚未发布。精确 ID、digest、inspect 和日志见[本机阶段验收](../计划对齐与实践/实践记录2_本机/README.md)。独立 Reap manifest 的 batteries 为 `6032d2c…`，最终 Mathlib runtime 为 `cabbb5a…` 并重新编译通过；两份 manifest 已归档，不能宣称整个依赖环境不变。完整依赖锁、SBOM 和干净重建验收仍待完成。

## B：GPU 镜像（远端验收待完成）

[GPU Containerfile](gpu/Containerfile) 的 release 目标固定 AMD ROCm 7.2.4 / PyTorch 2.10 基础镜像 digest，将 `FrenzyMath/REAL-Prover` revision `fe76f68d9a88f342cb7b546307c20292fea9cced` 烘焙进镜像，并检查模型 `hidden_size=3584`。页面预装环境不能替代此镜像的运行证据。

用户已允许先在远端宿主验证真实 GPU TTT，再固定已验证的依赖、代码与 7B 构建独立 B，最后在支持容器的环境复验 A/B。当前宿主预装 torch 2.11/HIP 7.2 与上述 B 基础层不是同一环境，打包时必须显式核对版本并重新验收；不把宿主成功直接视为此 Containerfile 通过。

正式 B 优先使用已验证的远端模型构建 `release-existing`，不在本机下载权重。受控 context 的可执行准备、recipe 哈希更新、严格 `real-search --gamma 0.99` 默认服务和设备运行模板见[交付 Docker 说明](../v1-result/docker/README.md)。这些是待具备合法 builder/AMD 容器权限后验证的入口，不绕过当前 ModelScope 限制；原 `release` 在线下载路径不是当前推荐复现方式。

`dev-no-weights` 仅用于 toy 控制面测试，不是正式交付镜像。GPU runtime 提供 session policy/value 与 learn/snapshot/restore 路由；GPU actor 串行切换 adapter 和执行计算。远端宿主的真实 7B 已通过三次合成负事件更新、有限数值、双 session 参数/optimizer/metadata 隔离与恢复、全量冻结 base 指纹检查（94.0425s）。**这是宿主合成预检，不是 Lean 反馈 TTT，也不证明 B 容器已运行。** 两 session 共存不表示 GPU kernel 并发。

## 远端执行与交付

只用 Edge + OpenCLI 控制远端 AMD；登录、验证码及实例的启动、停止、重启全部由用户负责。自动闲置保护已暂停，旧“超过 10 分钟自动关闭”授权不再适用；Codex 不自行启停实例。

本地已准备不含权重的部署小包、22 个 Linux wheels、[requirements-remote.lock](gpu/requirements-remote.lock)、官方模型清单和 config；局部 WSL 导入检查不等于完整模型兼容性。复现与哈希见[开机前准备](../计划对齐与实践/可复用记录/07-开机前本地准备与部署包.md)。

后续远端已按固定版本/哈希从用户认可的阿里云 PyPI 镜像安装 22 包，依赖闭包与核心库导入通过，原宿主 torch 2.11.0 未替换；真实 7B GPU 预检入口与边界见[隔离环境与预检](../计划对齐与实践/可复用记录/09-远端隔离环境与7B-GPU预检.md)。这些宿主证据不能自动迁移至当前 Containerfile 的 PyTorch 2.10 基础层。

实例就绪后先验证模型网络/来源、全权重哈希与张量索引，再检查隔离 Python 环境，保留原宿主 ROCm torch。先完成宿主服务与 A 的真实 TTT，随后构建 B 并在支持容器的环境复验，正式双容器仍为 B health 通过后 A 运行，检查 mounts 与设备边界。最终要求包括真实 Lean visit/backup、GPU 参数更新、同一进行中的树后续消费新版本和最终 proof；历史 fresh-root、tiny SGD、toy 或小包生成均不能替代。详细设计见[双镜像方案](../计划对齐与实践/计划与设计对齐/02-双镜像设计.md)。
